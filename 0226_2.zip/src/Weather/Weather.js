/* global kakao */
import React, { useEffect, useRef, useState } from 'react';

// 좌표 변환 상수
const RE = 6371.00877; // 지구 반지름 (km)
const GRID = 5.0; // 격자 간격 (km)
const SLAT1 = 30.0; // 투영 위도 1 (도)
const SLAT2 = 60.0; // 투영 위도 2 (도)
const OLON = 126.0; // 기준 경도 (도)
const OLAT = 38.0; // 기준 위도 (도)
const XO = 43; // 원점 X 좌표 (GRID)
const YO = 136; // 원점 Y 좌표 (GRID)

// LCC DFS 좌표 변환 함수
function dfs_xy_conv(code, v1, v2) {
    const DEGRAD = Math.PI / 180.0;
    const RADDEG = 180.0 / Math.PI;

    const re = RE / GRID;
    const slat1 = SLAT1 * DEGRAD;
    const slat2 = SLAT2 * DEGRAD;
    const olon = OLON * DEGRAD;
    const olat = OLAT * DEGRAD;

    let sn = Math.tan(Math.PI * 0.25 + slat2 * 0.5) / Math.tan(Math.PI * 0.25 + slat1 * 0.5);
    sn = Math.log(Math.cos(slat1) / Math.cos(slat2)) / Math.log(sn);
    let sf = Math.tan(Math.PI * 0.25 + slat1 * 0.5);
    sf = Math.pow(sf, sn) * Math.cos(slat1) / sn;
    let ro = Math.tan(Math.PI * 0.25 + olat * 0.5);
    ro = re * sf / Math.pow(ro, sn);
    let rs = {};
    if (code === "toXY") {
        rs['lat'] = v1;
        rs['lng'] = v2;
        let ra = Math.tan(Math.PI * 0.25 + (v1) * DEGRAD * 0.5);
        ra = re * sf / Math.pow(ra, sn);
        let theta = v2 * DEGRAD - olon;
        if (theta > Math.PI) theta -= 2.0 * Math.PI;
        if (theta < -Math.PI) theta += 2.0 * Math.PI;
        theta *= sn;
        rs['x'] = Math.floor(ra * Math.sin(theta) + XO + 0.5);
        rs['y'] = Math.floor(ro - ra * Math.cos(theta) + YO + 0.5);
    }
    return rs;
}

function calculateWindDirection(u, v) {
    // UUU와 VVV 값을 사용하여 풍향 계산
    const angle = Math.atan2(u, v) * (180 / Math.PI);
    const degrees = (angle < 0 ? angle + 360 : angle);

    if (degrees > 315 || degrees <= 45) {
        return 'N-NE';
    } else if (degrees > 45 && degrees <= 90) {
        return 'NE-E';
    } else if (degrees > 90 && degrees <= 135) {
        return 'E-SE';
    } else if (degrees > 135 && degrees <= 180) {
        return 'SE-S';
    } else if (degrees > 180 && degrees <= 225) {
        return 'S-SW';
    } else if (degrees > 225 && degrees <= 270) {
        return 'SW-W';
    } else if (degrees > 270 && degrees <= 315) {
        return 'W-NW';
    } else {
        return 'NW-N';
    }
}


// KakaoMap 컴포넌트
const KakaoMap = () => {
    const mapRef = useRef(null);
    const [map, setMap] = useState(null);
    const [weatherData, setWeatherData] = useState(null);

    // 기상청 API를 사용하여 날씨 데이터 가져오기
    const fetchWeatherData = (gridX, gridY) => {
        // 현재 시간 기준으로 baseDate 및 baseTime 설정
        const now = new Date();
        let baseDate;
        let baseTime;

        if (now.getMinutes() >= 40) {
            // 40분 이후이면 현재 시간을 사용
            baseDate = `${now.getFullYear()}${String(now.getMonth() + 1).padStart(2, '0')}${String(now.getDate()).padStart(2, '0')}`;
            baseTime = `${String(now.getHours()).padStart(2, '0')}00`;
        } else {
            // 40분 이전이면 한 시간 전 데이터를 사용
            now.setHours(now.getHours() - 1);
            baseDate = `${now.getFullYear()}${String(now.getMonth() + 1).padStart(2, '0')}${String(now.getDate()).padStart(2, '0')}`;
            baseTime = `${String(now.getHours()).padStart(2, '0')}00`;
        }

        const encodedServiceKey = 'BHpQTexrH%2FOEjVR2zDPhMQ3v%2FZkfRBCR5LD8YR6iUBG8td9NeFggtx2yNVB6w4ttERGo7dTzRq5OTkCnC40zfw%3D%3D'; // 여기에 실제 인코딩된 서비스 키를 사용하세요.
        const url = `http://apis.data.go.kr/1360000/VilageFcstInfoService_2.0/getUltraSrtNcst`;
        const queryParams = `?serviceKey=${encodedServiceKey}&pageNo=1&numOfRows=10&dataType=JSON&base_date=${baseDate}&base_time=${baseTime}&nx=${gridX}&ny=${gridY}`;

        fetch(url + queryParams)
            .then(response => response.json())
            .then(data => {
                console.log(data); // API 응답 로깅
                if (data.response.header.resultCode === "00" && data.response.body.items.item.length > 0) {
                    const { T1H, REH, RN1, UUU, VVV, WSD } = data.response.body.items.item.reduce((acc, current) => {
                        acc[current.category] = current.obsrValue;
                        return acc;
                    }, {});
                    setWeatherData({ T1H, REH, RN1, UUU, VVV, WSD });
                } else {
                    console.error('날씨 데이터를 가져오는 데 실패했습니다.', data.response.header.resultMsg);
                }
            })
            .catch(error => {
                console.error('날씨 데이터를 가져오는 중 오류:', error);
            });
    };



    // 현재 위치 가져오기 및 지도에 마커 표시
    const getCurrentLocation = () => {
        if (navigator.geolocation) {
            navigator.geolocation.getCurrentPosition((position) => {
                const lat = position.coords.latitude;
                const lon = position.coords.longitude;
                const grid = dfs_xy_conv("toXY", lat, lon);

                // 지도의 중심을 현재 위치로 이동
                const moveLatLon = new kakao.maps.LatLng(lat, lon);
                if (map) {
                    map.setCenter(moveLatLon);

                    // 현재 위치에 새로운 마커 생성
                    const marker = new kakao.maps.Marker({
                        position: moveLatLon
                    });
                    marker.setMap(map);
                }

                // 날씨 데이터 가져오기
                fetchWeatherData(grid.x, grid.y);
            }, () => {
                alert('위치 정보를 가져올 수 없습니다.');
            });
        } else {
            alert('이 브라우저에서는 Geolocation이 지원되지 않습니다.');
        }
    };

    // 카카오 맵 초기화
    useEffect(() => {
        const appKey = 'f6bac856fcd6429389ace76f13ffaf23'; // 실제 카카오 앱 키로 대체해야 합니다.
        const script = document.createElement('script');
        script.async = true;
        script.src = `//dapi.kakao.com/v2/maps/sdk.js?appkey=${appKey}&autoload=false`;
        document.head.appendChild(script);

        script.onload = () => {
            kakao.maps.load(() => {
                const mapContainer = mapRef.current; // 지도를 표시할 div
                const mapOption = {
                    center: new kakao.maps.LatLng(33.450701, 126.570667), // 지도의 중심좌표
                    level: 3 // 지도의 확대 레벨
                };

                // 지도 생성 및 map 상태 업데이트
                const kakaoMap = new kakao.maps.Map(mapContainer, mapOption);
                setMap(kakaoMap);
            });
        };

        return () => {
            document.head.removeChild(script);
        };
    }, []);

    return (
        <div>
            <div ref={mapRef} style={{ width: '100%', height: '350px' }}></div>
            <button onClick={getCurrentLocation}>내 위치 가져오기</button>
            {weatherData && (
                <div>
                    <p>기온: {weatherData.T1H}°C</p>
                    <p>습도: {weatherData.REH}%</p>
                    <p>강수량: {weatherData.RN1}mm</p>
                    <p>풍향: {calculateWindDirection(weatherData.UUU, weatherData.VVV)}</p>
                    <p>풍속: {weatherData.WSD}m/s</p>
                </div>
            )}
        </div>
    );
};

export default KakaoMap;
