package com.ZeroWaveV2.FireAlertV2.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ZeroWaveV2.FireAlertV2.dto.ResultDto;
import com.ZeroWaveV2.FireAlertV2.model.Result;
import com.ZeroWaveV2.FireAlertV2.service.ResultService;

@RestController
@RequestMapping("/api/result")
public class ResultController {
    
    @Autowired
    private ResultService resultService;

    @PostMapping
    public ResponseEntity<Result> createResult(@RequestBody ResultDto resultDto) {
        Result result = resultService.createResult(resultDto);
        return ResponseEntity.ok(result);
    }
}