package com.ZeroWaveV2.FireAlertV2.service;

import com.ZeroWaveV2.FireAlertV2.model.Result;
import com.ZeroWaveV2.FireAlertV2.dto.ResultDto;
import com.ZeroWaveV2.FireAlertV2.repository.ResultRepository;
import com.ZeroWaveV2.FireAlertV2.repository.FireReceptionRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class ResultService {

    @Autowired
    private ResultRepository resultRepository;  

    @Transactional
    public Result createResult(ResultDto resultDto) {        

        Result result = new Result();
        result.setTitle(resultDto.getTitle());
        result.setDtime(resultDto.getDtime());
        result.setCdate(resultDto.getCdate());
        result.setWtime(resultDto.getWtime());
        result.setFf(resultDto.getFf());
        result.setFtruck(resultDto.getFtruck());
        result.setHc(resultDto.getHc());
        result.setFw(resultDto.getFw());
        result.setLosses(resultDto.getLosses());
        result.setLmoney(resultDto.getLmoney());
        result.setDarea(resultDto.getDarea());
        result = resultRepository.save(result);
       
        return result;
    }    
}
