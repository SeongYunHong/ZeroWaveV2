package com.ZeroWaveV2.FireAlertV2.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter

public class DeleteUserDto {
	private String hp;
}
