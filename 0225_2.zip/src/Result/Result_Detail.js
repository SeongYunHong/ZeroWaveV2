import React, { useState } from 'react';
import axios from 'axios';

function Result_Detail() {
    const [result, setResult] = useState({
        dtime: '',
        cdate: '',
        wtime: '',
        ff: 0,
        ftruck: 0,
        hc: 0,
        fw: 0,
        losses: 0,
        lmoney: 0,
        darea: 0,
    });

    const handleChange = (e) => {
        setResult({ ...result, [e.target.name]: e.target.value });
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            const response = await axios.post('http://localhost:8081/api/result', result);
            console.log(response.data);
            alert('제출되었습니다.');
        } catch (error) {
            console.error('Error posting result', error);
        }
    };

    const formatDateTimeForInput = (inputString) => {
        if (!inputString) return ''; // 입력값이 없을 경우 빈 문자열 반환
        const date = new Date(inputString);
        const year = date.getFullYear();
        const month = (date.getMonth() + 1).toString().padStart(2, '0');
        const day = date.getDate().toString().padStart(2, '0');
        const hours = date.getHours().toString().padStart(2, '0');
        const minutes = date.getMinutes().toString().padStart(2, '0');
        const seconds = date.getSeconds().toString().padStart(2, '0'); // 초 추가
    
        // "YYYY-MM-DDThh:mm:ss" 형식으로 변환
        return `${year}-${month}-${day}T${hours}:${minutes}:${seconds}`;
    };

    const formatTimeForInput = (inputString) => {
        // 입력값이 없을 경우 빈 문자열 반환
        if (!inputString) return '';
    
        // 현재 날짜를 기준으로 한 Date 객체 생성
        const currentDate = new Date();
        const [hours, minutes, seconds] = inputString.split(':');
        
        // 시간, 분, 초를 설정
        currentDate.setHours(parseInt(hours, 10) || 0);
        currentDate.setMinutes(parseInt(minutes, 10) || 0);
        currentDate.setSeconds(parseInt(seconds, 10) || 0);
    
        // "HH:mm:ss" 형식으로 변환
        const formattedHours = currentDate.getHours().toString().padStart(2, '0');
        const formattedMinutes = currentDate.getMinutes().toString().padStart(2, '0');
        const formattedSeconds = currentDate.getSeconds().toString().padStart(2, '0');
    
        return `${formattedHours}:${formattedMinutes}:${formattedSeconds}`;
    };

    const calculateTimeDifference = (start, end) => {
        const startDate = new Date(start);
        const endDate = new Date(end);
        const difference = endDate - startDate; // 밀리초 단위 차이
      
        let seconds = Math.floor((difference / 1000) % 60);
        let minutes = Math.floor((difference / (1000 * 60)) % 60);
        let hours = Math.floor((difference / (1000 * 60 * 60)) % 24);
      
        hours = (hours < 10) ? "0" + hours : hours;
        minutes = (minutes < 10) ? "0" + minutes : minutes;
        seconds = (seconds < 10) ? "0" + seconds : seconds;
      
        return `${hours}:${minutes}:${seconds}`;
      }; 

    return (
        <form onSubmit={handleSubmit}>
            <div><label>출동 시각: <input name="dtime" type="datetime-local" value={formatDateTimeForInput(result.dtime)} onChange={handleChange} /></label></div>
            <div><label>종료 시간: <input name="cdate" type="datetime-local" value={formatDateTimeForInput(result.cdate)} onChange={handleChange} /></label></div>
            <div><label>걸린 시간: <input name="wtime" type="datetime-local" step="1" value={formatDateTimeForInput(result.wtime)} onChange={handleChange} /></label></div>
            <div><label>출동 인원: <input name="ff" type="number" value={result.ff} onChange={handleChange} /></label></div>
            <div><label>출동 소방차: <input name="ftruck" type="number" value={result.ftruck} onChange={handleChange} /></label></div>
            <div><label>출동 헬기: <input name="hc" type="number" value={result.hc} onChange={handleChange} /></label></div>
            <div><label>소화수: <input name="fw" type="number" value={result.fw} onChange={handleChange} /></label></div>
            <div><label>사상자: <input name="losses" type="number" value={result.losses} onChange={handleChange} /></label></div>
            <div><label>피해 금액: <input name="lmoney" type="number" value={result.lmoney} onChange={handleChange} /></label></div>
            <div><label>피해 면적: <input name="darea" type="number" value={result.darea} onChange={handleChange} /></label></div>
            <button type="submit">Submit</button>
        </form>
    );
}

export default Result_Detail;