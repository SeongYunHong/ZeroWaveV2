import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import axios from 'axios';
import './Admin_Notice_Detail.css';

const Admin_Notice_Update = () => {
    const [title, setTitle] = useState(''); // 여기서 초기값을 ''로 설정
    const [post, setPost] = useState(''); // 여기서 초기값을 ''로 설정
    const [imgurl, setImgurl] = useState(''); // 여기서 초기값을 ''로 설정
    const { noticeId } = useParams();
    const navigate = useNavigate();

    useEffect(() => {
        const fetchUserRole = async () => {
          const token = localStorage.getItem('token');
          if (!token) {
            alert('관리자만 접근할 수 있는 페이지입니다.');
            navigate('/');
            return;
          }
    
          try {
            const response = await axios.get('http://localhost:8081/api/auth/role', {
              headers: {
                'Authorization': `Bearer ${token}`
              }
            });
            // 관리자인지 확인
            if (!response.data.roles.includes('ROLE_ADMIN')) {
              alert('관리자만 접근할 수 있는 페이지입니다.');
              navigate('/');
              return;
            }
          } catch (error) {
            console.error('Role fetching failed', error);
            navigate('/');
          }
        };
    
        fetchUserRole();
      }, [navigate]);

    useEffect(() => {
        // 공지사항의 현재 정보를 불러와서 폼에 세팅
        const fetchNoticeDetail = async () => {
            try {
                const response = await axios.get(`http://localhost:8081/api/notice/${noticeId}`);
                const data = response.data;
                setTitle(data.title || ''); // API 응답에서 undefined가 오는 경우를 대비해 기본값 설정
                setPost(data.post || ''); // API 응답에서 undefined가 오는 경우를 대비해 기본값 설정
                setImgurl(data.imgurl || ''); // API 응답에서 undefined가 오는 경우를 대비해 기본값 설정
            } catch (error) {
                console.error('공지사항 정보 불러오기 실패', error);
                alert('공지사항 정보를 불러오는 데 실패했습니다.');
            }
        };
        
        fetchNoticeDetail();
    }, [noticeId]); // 의존성 배열에 noticeId 추가

    const handleSubmitAdminNotice = async (event) => {
        event.preventDefault();

        try {
            await axios.put(`http://localhost:8081/api/notice/${noticeId}`, {
                title,
                post,
                imgurl,
            });

            alert('공지사항이 성공적으로 수정되었습니다.');
            navigate('/admin/notice');
        } catch (error) {
            console.error('공지사항 수정 실패', error);
            alert('공지사항 수정에 실패했습니다.');
        }
    };

    const gotoNotice = () => {
        navigate('/admin/notice')
    }

    return (
        <div className='notice_detail'>
            <form onSubmit={handleSubmitAdminNotice}>
                <h1>공지사항 수정</h1>
                <div className="notice_info">
                    {/* <label htmlFor="title">제목</label> */}
                    <input id="title" value={title} onChange={(e) => setTitle(e.target.value)} />
                </div>
                <div>
                    {/* <label htmlFor="imgurl">이미지 URL</label> */}
                    <input id="imgurl" value={imgurl} onChange={(e) => setImgurl(e.target.value)} />
                </div>
                <div className="notice_info">
                    {/* <label htmlFor="post">내용</label> */}
                    <textarea id="post" value={post} onChange={(e) => setPost(e.target.value)} />
                </div>
                <div className="notice_navigation">
                    <button type="submit">수정하기</button>
                    <button onClick={gotoNotice}>목록으로</button>
                </div>
            </form>
        </div>
    );
}

export default Admin_Notice_Update;
