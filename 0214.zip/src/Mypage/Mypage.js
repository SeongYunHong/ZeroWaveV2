import React, { useEffect, useState } from 'react';
import axios from 'axios';
// import Modal from 'react-modal';

// Modal.setAppElement('#root');

function Mypage() {
  const [userInfo, setUserInfo] = useState({ name: '', hp: '' });

  useEffect(() => {
    fetchUserInfo();
  }, []);

  const fetchUserInfo = async () => {
    try {
      const response = await axios.get('http://localhost:8081/api/mypage/info', {
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('token')}`
        }
      });
      setUserInfo({
        name: response.data.name,
        hp: response.data.hp,
      });
    } catch (error) {
      console.error('회원 정보 조회 실패', error);
    }
  };

  return (
    <div>
      <h2>My Page</h2>
      <p>이름: {userInfo.name}</p>
      <p>전화번호: {userInfo.hp}</p>
    </div>
  );
}
export default Mypage;