import React, { useState, useEffect } from 'react';
import { BrowserRouter, Routes, Route, Link, useLocation, useNavigate } from 'react-router-dom';
import Mainpage from './Mainpage/Mainpage';
import Mountain from './Mountain/Mountain';
import Notice from './Notice/Notice';
import Mypage from './Mypage/Mypage';
import Signup from './Signup/Signup';
import './App.css';
import logoImage from './static/logo.png';

const Navigation = () => {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const location = useLocation();
  const navigate = useNavigate();

  useEffect(() => {
    // 로컬 스토리지에서 토큰 유무를 확인하여 로그인 상태 설정
    const token = localStorage.getItem('token');
    setIsLoggedIn(!!token); // 토큰이 있으면 true, 없으면 false
  }, []);

  // 로그인 페이지에서는 네비게이션 바를 표시하지 않음
  if (location.pathname === '/login') {
    return null;
  }

  const handleLogout = (event) => {
    event.preventDefault(); // 링크의 기본 동작 방지
    localStorage.removeItem('token'); // 인증 토큰 삭제
    // localStorage.setItem('isLoggedIn', 'false'); // 로그인 상태를 false로 설정, 필요에 따라 사용
    setIsLoggedIn(false);
    navigate('/'); // 메인 페이지로 리다이렉트
  };

  return (
    <nav className='navbar'>
      <Link to={"/"} className='logo'>
        <img src={logoImage} alt="로고" />
      </Link>
      <div className='navbar_menu'>
        <li className='nav-item'>
          <Link to="/mountain" className='nav-link'>추천 등산로</Link>
        </li>
        <li className='nav-item'>
          <Link to="/notice" className='nav-link'>게시판</Link>
        </li>
        <li className='nav-item'>
          <Link to="/mypage" className='nav-link'>마이페이지</Link>
        </li>
        {isLoggedIn ? (
          <li className='nav-item'>
            <Link to="/" onClick={handleLogout} className='nav-link'>로그아웃</Link>
          </li>
        ) : (
          <li className='nav-item'>
            <Link to="/login" className='nav-link'>로그인 및 회원가입</Link>
          </li>
        )}
      </div>
    </nav>
  );
};

function App() {
  return (
    <BrowserRouter>
      <Navigation />
      <div className="App">
        <div className='container mt-3'>
          <Routes>
            <Route path="/" element={<Mainpage />} />
            <Route path="/mountain" element={<Mountain />} />
            <Route path="/notice" element={<Notice />} />
            <Route path="/mypage" element={<Mypage />} />
            <Route path="/login" element={<Signup />} />
          </Routes>
        </div>
      </div>
    </BrowserRouter>
  );
}

export default App;
