import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import './Signup.css';
// import kakaoLoginImage from '/root/zerowave/src/static/kakaologin.png';

function Signup() {
  const [isLoginView, setIsLoginView] = useState(true);
  const [isMoving, setIsMoving] = useState(false);
  const [hp, setHp] = useState('');
  const [password, setPassword] = useState('');
  const [passwordConfirm, setPasswordConfirm] = useState('');
  const [userName, setUserName] = useState('');
  const [errorMessage, setErrorMessage] = useState('');
  const navigate = useNavigate();

  const toggleView = () => {
    setIsLoginView(!isLoginView);
    setIsMoving(!isMoving);
    // 입력 필드 상태 초기화
    setHp('');
    setPassword('');
    setPasswordConfirm('');
    setUserName('');
    setErrorMessage(''); 
  };
//--------------------------------------------------박스에 값 입력하면 바뀌는거
  const handleChange = (event) => {
    const { name, value } = event.target;
    switch (name) {
      case 'hp':
        setHp(value);
        break;
      case 'password':
        setPassword(value);
        break;
      case 'passwordConfirm':
        setPasswordConfirm(value);
        break;
      case 'userName':
        setUserName(value);
        break;
      default:
        break;
    }
  };

//--------------------------------------------------회원가입 로그인 화면만 회색으로 지정
  useEffect(() => {
    // 현재 body의 배경색을 저장
    const originalBackgroundColor = document.body.style.backgroundColor;
    // 배경색을 원하는 색으로 변경
    document.body.style.backgroundColor = '#A8A8A8';

    // 컴포넌트가 언마운트될 때 원래 배경색으로 복원
    return () => {
      document.body.style.backgroundColor = originalBackgroundColor;
    };
  }, []);
//--------------------------------------------------아이디 중복확인 버튼 눌렀을 때
const handleHpcheck = () => {
  axios.post('http://localhost:8081/api/check_hp', { hp: hp })
    .then(response => {
      // 서버 응답에 따라 다른 메시지 표시
      if (response.data.exists) {
        alert('이미 존재하는 사용자 연락처입니다.');
      } else {
        alert('사용 가능한 연락처입니다.');
      }
    })
    .catch(error => {
      console.error('checkhp error:', error);
      alert('중복 확인 과정에서 오류가 발생했습니다.');
    });
};
//--------------------------------------------------회원 가입 버튼 눌렀을 때
const handleSignUp = async () => {
  if (password !== passwordConfirm) {
    alert('비밀번호와 비밀번호 확인이 일치하지 않습니다.');
    return;
  }
  if (password.length < 6 || password.length > 15) {
    alert('비밀번호는 6자리 이상 15자리 이하로 설정해주세요.');
    return;
  }
  
  try {
    const response = await axios.post('http://localhost:8081/api/register', { hp, password, userName });
    console.log('Signup success:', response);
    alert('회원가입에 성공하였습니다!');
    // 여기서 바로 toggleView를 호출하는 대신, 외부에서 호출되도록 변경
    return true; // 성공 시 true 반환
  } catch (error) {
    console.error('Signup error:', error);
    if (error.response && error.response.status === 409) {
      alert('이미 존재하는 사용자 연락처입니다.');
    } else {
      alert('회원가입 과정에서 오류가 발생했습니다.');
    }
    return false; // 실패 시 false 반환
  }
};

// combinedOnChange 함수 : 회원가입이 완료되면 자동으로 로그인 박스로 전환되게 만드는 함수 
const combinedOnChange = async (event) => {
  const signUpSuccess = await handleSignUp(event);
  if (signUpSuccess) {
    toggleView(); // 회원가입 성공 후 뷰 전환
  }
};

//--------------------------------------------------로그인 버튼 눌렀을 때
const handleLogin = () => {
  axios.post('http://localhost:8081/api/login', { hp, password })
    .then(response => {
      const { token } = response.data;
      localStorage.setItem('token', token); // JWT를 localStorage에 저장
      localStorage.setItem('isLoggedIn', 'true');
      window.location.href = '/'; //새로고침해서 이동
      console.log('Login success:', response);
      alert('로그인에 성공하였습니다!');
    })
    .catch(error => {
      console.error('Login error:', error);
      if (error.response && error.response.status === 403) {
        alert('아이디 또는 비밀번호가 잘못되었습니다.');
      } else {
        alert('로그인 과정에서 오류가 발생했습니다.');
      }
    });
};

//--------------------------------------------------Enter 키 누를 때 로그인 처리하는 함수
const handleKeyDown = (event) => {
  if (event.key === 'Enter') {
    handleLogin(); // Enter 키가 눌렸을 때 로그인 핸들러 호출
  }
};

//--------------------------------------------------
  return (
    <div className="signup-background" style={{ backgroundColor: '#A8A8A8', minHeight: '100vh' }}>
    <div className="container">
      <div className="backbox">
        <div className={`loginMsg ${isLoginView ? '' : 'visibility'}`}>
          <div className="textcontent">
            <p className="title">계정이 없으신가요?</p>
            <p>회원가입을 통해 산림을 보호하세요!</p>
            <button id="switch1" onClick={toggleView}>SIGN UP</button>
          </div>
        </div>
        <div className={`signupMsg ${isLoginView ? 'visibility' : ''}`}>
          <div className="textcontent">
            <p className="title">이미 계정이 있으신가요?</p>
            <p>산림을 지켜주세요!</p>
            <button id="switch2" onClick={toggleView}>LOG IN</button>
          </div>
        </div>
      </div>

      <div className={`frontbox ${isMoving ? 'moving' : ''}`}>
        {isLoginView ? (
          <div className={`login ${isLoginView ? '' : 'hide'}`}>
            <h2>LOG IN</h2>
            <div className="inputbox">
              <input type="text" name="hp" placeholder="연락처" value={hp} onChange={handleChange} />
              <input type="password" name="password" placeholder="비밀번호" value={password} onChange={handleChange} onKeyDown={handleKeyDown} />
            </div>
            <p>FORGET PASSWORD?</p>
            {/* <button type="button" className="kakao-login-btn"><img src={kakaoLoginImage}/></button> */}
            <button onClick={handleLogin}>LOG IN</button>
          </div>
        ) : (
          <div className={`signup ${isLoginView ? 'hide' : ''}`}>
            <h2>SIGN UP</h2>
            <div className="inputbox">
              <input type="text" name="hp" placeholder="연락처" value={hp} onChange={handleChange} />
              <button onClick={handleHpcheck} className="hp-check-button">중복 확인</button>
              <input type="password" name="password" placeholder="비밀번호(6자리 이상 15자리 이하)" value={password} onChange={handleChange} />
              <input type="password" name="passwordConfirm" placeholder="비밀번호 재입력" value={passwordConfirm} onChange={handleChange} />
              <input type="text" name="userName" placeholder="이름" value={userName} onChange={handleChange}  onKeyDown={handleKeyDown}/>
            </div>
            
            <button onClick={combinedOnChange}>SIGN UP</button>
          </div>
        )}
      </div>
      </div>
      <div className="error-message">
        {errorMessage && <p>{errorMessage}</p>}
      </div>
    </div>
  );
}


export default Signup;