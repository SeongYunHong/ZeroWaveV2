
function Mainpage(){}

export default Mainpage;