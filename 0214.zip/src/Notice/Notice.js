import React from 'react';
import './Notice.css';

const Notice = () => {
  return (
    <div className="notice-container">
      <div className="notice-header">
        <h1>공지사항</h1>
      </div>
      <div className="notice-filter">
        <select className="notice-select">
          <option value="all">전체</option>
          {/* 다른 옵션들 추가 가능 */}
        </select>
        <input className="notice-search" type="text" placeholder="검색어를 입력하세요" />
        <button className="notice-search-btn">검색</button>
      </div>
      <div className="notice-list">
        <table className="notice-table">
          <thead>
            <tr>
              <th>번호</th>
              <th>제목</th>
              <th>작성일</th>
            </tr>
          </thead>
          <tbody>
            {/* 예시 데이터 */}
            <tr>
              <td></td>
              <td></td>
              <td></td>
            </tr>
            {/* 다른 공지사항 항목들 */}
          </tbody>
        </table>
      </div>
      <div className="notice-pagination">
        <button>&lt;</button>
        <button className="active">1</button>
        <button>&gt;</button>
      </div>
    </div>
  );
}

export default Notice;
