package com.ZeroWaveV2.FireAlertV2.model;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import org.hibernate.annotations.ColumnDefault;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;
import org.hibernate.annotations.UpdateTimestamp;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.PrePersist;
import jakarta.persistence.Table;

import lombok.Data;
import lombok.RequiredArgsConstructor;

@Data
@RequiredArgsConstructor
@Entity
@Table(name = "fire_station")
public class FireStation {

    @Id
    @Column(name = "fs", length = 16, nullable = false)
    private String fs;
    
    @ManyToOne
    @JoinColumn(name = "tc", referencedColumnName = "tc")
    @OnDelete(action = OnDeleteAction.CASCADE)
    private FireTeam fireTeam;

    @Column(length = 96, nullable = false)
    private String password;
    
    @Column(name = "fs_add", length = 160)
	private String fsAdd;
    
    @Column(name = "fs_name", length = 80)
	private String fsName;
    
    @Column(name = "fph", length = 16)
	private String fph;
    
    @Column(length = 8)
    @ColumnDefault("'2'")
    private String userLevel;
    
    @CreationTimestamp
	@Column(name = "create_date", nullable = false, updatable = false)
	private Timestamp createDate;

	@UpdateTimestamp
	@Column(name = "modify_date")
	private Timestamp modifyDate;
        
    @PrePersist
    private void prePersist() {
        if (userLevel == null) {
        	userLevel = "2";
        }
    }
    
    @OneToMany(mappedBy = "fireStation", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private List<FireSituationRoom> fireSituationRoom = new ArrayList<>();
    
    FireStation(String fs, FireTeam fireTeam, String password, String fsAdd){
    	this.fs = fs;
    	this.fireTeam = fireTeam;
    	this.password = password;
    	this.fsAdd = fsAdd;
    }
}