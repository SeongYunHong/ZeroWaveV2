package com.ZeroWaveV2.FireAlertV2.model;

import org.hibernate.annotations.ColumnDefault;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.PrePersist;
import jakarta.persistence.Table;
import lombok.Data;

@Data
@Entity
@Table(name = "admin")
public class Admin {

	@Id
    @Column(name = "id", length = 16, nullable = false)
    private String id;
	
	@Column(length = 96, nullable = false)
    private String password;
	
	@Column(length = 8)
    @ColumnDefault("'3'")
    private String userLevel;
	
	@PrePersist
    private void prePersist() {
        if (userLevel == null) {
            userLevel = "3";
        }
    }
	
	public Admin() {
    }

    public Admin(String id, String password, String userLevel) {
        this.id = id;
        this.password = password;
        this.userLevel = userLevel;
    }
}