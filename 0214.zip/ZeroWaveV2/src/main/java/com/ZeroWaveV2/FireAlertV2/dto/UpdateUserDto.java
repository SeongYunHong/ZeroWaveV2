package com.ZeroWaveV2.FireAlertV2.dto;

import lombok.*;

@Getter
@Setter
public class UpdateUserDto {
	private String hp;
	private String currentPassword;
    private String newPassword;
}
