package com.ZeroWaveV2.FireAlertV2.dto;

public class DeleteUserDto {

}
