package com.ZeroWaveV2.FireAlertV2.controller;

import com.ZeroWaveV2.FireAlertV2.constants.ErrorMessages;
import com.ZeroWaveV2.FireAlertV2.dto.LoginDto;
import com.ZeroWaveV2.FireAlertV2.dto.UserRegistrationDto;
import com.ZeroWaveV2.FireAlertV2.jwt.JwtTokenProvider;
import com.ZeroWaveV2.FireAlertV2.service.UserService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.*;


@RestController
@RequestMapping("/api")
public class UserController {

    private final UserService userService;
    private final JwtTokenProvider jwtTokenProvider;

    public UserController(UserService userService, JwtTokenProvider jwtTokenProvider) {
        this.userService = userService;
        this.jwtTokenProvider = jwtTokenProvider;
    }

    // 연락처 중복 검사
    @PostMapping("/check_hp")
    public ResponseEntity<?> checkId(@RequestBody Map<String, String> data) {
        String hp = data.get("hp");
        if (hp == null || hp.isBlank()) {
            return ResponseEntity.badRequest().body(Map.of("message", "연락처를 입력하세요."));
        }

        if (userService.existsByHp(hp)) {
            return ResponseEntity.ok(Map.of("message", "이미 존재하는 연락처입니다.", "exists", true));
        } else {
            return ResponseEntity.ok(Map.of("message", "사용 가능한 연락처입니다.", "exists", false));
        }
    }

    // 회원가입
    @PostMapping("/register")
    public ResponseEntity<?> registerUser(@Valid @RequestBody UserRegistrationDto registrationDto) {
        var user = userService.registerUser(
        		registrationDto.getHp(),
                registrationDto.getPassword(),
                registrationDto.getUserName());

        if (user != null) {
            return ResponseEntity.ok(user);
        } else {
            return ResponseEntity
                    .status(HttpStatus.CONFLICT)
                    .body(Map.of("error", ErrorMessages.USER_ALREADY_EXISTS));
        }
    }

    // 로그인
    @PostMapping("/login")
    public ResponseEntity<?> login(@Valid @RequestBody LoginDto loginDto) {
        var user = userService.authenticate(loginDto.getHp(), loginDto.getPassword());
        if (user != null) {
            var jwtToken = jwtTokenProvider.createToken(user.getHp());
            return ResponseEntity.ok(Map.of("token", jwtToken));
        } else {
            return ResponseEntity
                    .status(HttpStatus.UNAUTHORIZED)
                    .body(Map.of("error", ErrorMessages.AUTHENTICATION_FAILED));
        }
    }
    
    // 회원 정보 수정
//    @GetMapping("/mypage")
//    @PostMapping("/register")
//    public ResponseEntity<?> updateUser(@Valid @RequestBody UpdateUserDto UpdateUserDto) {
//        var user = userService.registerUser(
//        		registrationDto.getHp(),
//                registrationDto.getPassword(),
//                registrationDto.getUserName());
//
//        if (user != null) {
//            return ResponseEntity.ok(user);
//        } else {
//            return ResponseEntity
//                    .status(HttpStatus.CONFLICT)
//                    .body(Map.of("error", ErrorMessages.USER_ALREADY_EXISTS));
//        }
//    }
}
