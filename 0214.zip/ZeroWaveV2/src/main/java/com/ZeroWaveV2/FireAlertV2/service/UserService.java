package com.ZeroWaveV2.FireAlertV2.service;

import com.ZeroWaveV2.FireAlertV2.model.Member;
import com.ZeroWaveV2.FireAlertV2.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

@Service
public class UserService {

    private final UserRepository userRepository;
    private final BCryptPasswordEncoder passwordEncoder;

    @Autowired
    public UserService(UserRepository userRepository, BCryptPasswordEncoder passwordEncoder) {
        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;
    }

    // 아이디 중복 확인
    public boolean existsByHp(String hp) {
        return userRepository.existsByHp(hp);
    }

    // 회원가입
    public Member registerUser(String hp, String password, String userName) {
        if (userRepository.findByHp(hp) != null) {
            // 사용자가 이미 존재하면 null을 반환
            return null;
        }

        // 사용자가 존재하지 않으면 새로운 User 객체를 생성하고 저장
        String encodedPassword = passwordEncoder.encode(password);
        Member newUser = new Member(hp, encodedPassword, userName);
        return userRepository.save(newUser);
    }

    // 로그인
    public Member authenticate(String hp, String password) {
        Member user = userRepository.findByHp(hp);
        if (user != null && passwordEncoder.matches(password, user.getPassword())) {
            return user;
        }
        return null;
    }
    
    // 회원정보 가져오기
    public Member info(String hp) {
    	Member user = userRepository.findByHp(hp);
        return user;
    }
    
    //비밀번호 수정
    public boolean updatepassword(String hp, String password, String newpassword) {
    	Member user = userRepository.findByHp(hp);
    	if (user == null || !passwordEncoder.matches(password, user.getPassword())) {
            return false;
        }
    	user.setPassword(passwordEncoder.encode(newpassword));
        userRepository.save(user);
        return true;
    }
}
