package com.ZeroWaveV2.FireAlertV2.model;

import java.sql.Timestamp;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.*;

@Entity
@Data
@RequiredArgsConstructor
@AllArgsConstructor
@Table(name = "mountain_recommend")
public class Mountain_recommend {
	
	@Id
	@Column(length=40)
	private String mt;
	
	@Column(name="address",length=160)
	private String address;
	
	@Column(length=8)
	private int height;
	
	@Column(length=8)
	private String mtime;
	
	@Column(length=240)
	private String imgurl;
	
	@Column(length=800)
	private String mtpost;
	
	@CreationTimestamp
	@Column(name = "create_date", nullable = false, updatable = false)
	private Timestamp createDate;
	
	@UpdateTimestamp
	@Column(name = "modify_date")
	private Timestamp modifyDate;	
}
