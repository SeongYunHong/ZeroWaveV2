package com.ZeroWaveV2.FireAlertV2.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.ZeroWaveV2.FireAlertV2.model.FireStation;
import com.ZeroWaveV2.FireAlertV2.repository.FireStationRepository;

@Service
public class FireStationService {
	private final FireStationRepository fireStationRepository;
	private final BCryptPasswordEncoder passwordEncoder;

	@Autowired
	public FireStationService(FireStationRepository fireStationRepository, BCryptPasswordEncoder passwordEncoder) {
		this.fireStationRepository = fireStationRepository;
		this.passwordEncoder = passwordEncoder;
	}

	// 로그인
	public FireStation fireStation_login(String fs, String password) {
		FireStation fireStation = fireStationRepository.findByFs(fs);
		if (fireStation != null && passwordEncoder.matches(password, fireStation.getPassword())) {
			return fireStation;
		}
		return null;
	}
}
