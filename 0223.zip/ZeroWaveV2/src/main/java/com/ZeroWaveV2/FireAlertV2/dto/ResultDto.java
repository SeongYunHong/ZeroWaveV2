package com.ZeroWaveV2.FireAlertV2.dto;

import java.util.Date;

import lombok.*;

@Data
@RequiredArgsConstructor
@AllArgsConstructor
public class ResultDto {
	private int dispatch;
    private String title;
    private String imgurl; // FireReception의 imgurl
    private String gps; // FireReception의 gps
    private Date dtime;
    private Date cdate;
    private Date wtime;
    private int ff;
    private int ftruck;
    private int hc;
    private int fw;
    private int losses;
    private int lmoney;
    private int darea; 
}
