package com.ZeroWaveV2.FireAlertV2.controller;

import com.ZeroWaveV2.FireAlertV2.dto.FireReceptionDto;
import com.ZeroWaveV2.FireAlertV2.dto.ResultDto;
import com.ZeroWaveV2.FireAlertV2.model.Result;
import com.ZeroWaveV2.FireAlertV2.service.ResultService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/results")
public class ResultController {

    @Autowired
    private ResultService resultService;

    // 새로운 Result를 생성하는 POST 엔드포인트
    @PostMapping
    public ResponseEntity<Result> createResult(@RequestBody ResultDto resultDto) {
        Result result = resultService.createResult(resultDto);
        return ResponseEntity.ok(result);
    }

    // 저장된 모든 Result를 조회하는 GET 엔드포인트
    @GetMapping
    public ResponseEntity<List<ResultDto>> getResults(@AuthenticationPrincipal UserDetails currentUser) {
        // UserDetails에서 소방팀의 Fs를 추출
        String fs = currentUser.getUsername(); // JWT 토큰에 저장된 Fs 정보 사용

        // 해당 hp를 기반으로 FireReception 정보 조회
        List<ResultDto> results = resultService.findByFs(fs);
        
        if (results.isEmpty()) {
            return ResponseEntity.notFound().build();
        }
        
        return ResponseEntity.ok(results);
    }
}
