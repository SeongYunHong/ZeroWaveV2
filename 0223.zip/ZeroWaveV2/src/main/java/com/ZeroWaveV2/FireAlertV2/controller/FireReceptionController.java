package com.ZeroWaveV2.FireAlertV2.controller;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.ZeroWaveV2.FireAlertV2.dto.FireReceptionDto;
import com.ZeroWaveV2.FireAlertV2.model.FireReception;
import com.ZeroWaveV2.FireAlertV2.repository.FireReceptionRepository;
import com.ZeroWaveV2.FireAlertV2.service.FireReceptionService;

import jakarta.persistence.EntityNotFoundException;

@RestController
@RequestMapping("/api/fireReception")
public class FireReceptionController {
    
    @Autowired
    private FireReceptionService fireReceptionService;
    
    @Autowired
	private FireReceptionRepository fireReceptionRepository;

    @GetMapping
    public ResponseEntity<List<FireReceptionDto>> getFireReceptions(@AuthenticationPrincipal UserDetails currentUser) {
        // UserDetails에서 사용자의 hp를 추출
        String hp = currentUser.getUsername(); // JWT 토큰에 저장된 hp 정보 사용

        // 해당 hp를 기반으로 FireReception 정보 조회
        List<FireReceptionDto> fireReceptions = fireReceptionService.findByHp(hp);
        
        if (fireReceptions.isEmpty()) {
            return ResponseEntity.notFound().build();
        }
        
        return ResponseEntity.ok(fireReceptions);
    }

    @PostMapping
    public ResponseEntity<Void> receiveFireAlert(@AuthenticationPrincipal UserDetails userDetails,
                                                 @RequestParam("image") MultipartFile image,
                                                 @RequestParam("gps") String gps) {
        if (userDetails == null) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
        }

        try {
            String userHp = userDetails.getUsername();
            fireReceptionService.processFireAlert(userHp, image, gps);
        } catch (EntityNotFoundException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }

        return ResponseEntity.ok().build();
    }
    
    // 산불 현황
    @GetMapping("/count/{progressCode}")
    public ResponseEntity<Long> getCountByProgressCode(@PathVariable int progressCode) {
        String progress;
        switch (progressCode) {
            case 0:
                progress = "진화 중";
                break;
            case 1:
                progress = "진화 완료";
                break;
            case 2:
                progress = "산불 외 종료";
                break;
            default:
                return ResponseEntity.badRequest().body(null);
        }
        long count = fireReceptionService.getCountByProgress(progress);
        return ResponseEntity.ok(count);
    }
    
    // 특정 사용자의 FireReception 데이터 조회
 	@GetMapping("/user")
 	public ResponseEntity<List<FireReceptionDto>> getFireReceptionsForUser(
 			@AuthenticationPrincipal UserDetails currentUser) {
 		String hp = currentUser.getUsername();
 		List<FireReception> fireReceptions = fireReceptionRepository.findByUser_Hp(hp);
 		if (fireReceptions.isEmpty()) {
 			return ResponseEntity.notFound().build();
 		}

 		List<FireReceptionDto> dtos = fireReceptions.stream()
 	            .map(reception -> new FireReceptionDto(reception.getNum(), reception.getUser().getHp(),
 	                    reception.getImgurl(), reception.getAdate(), reception.getGps(), reception.getProgress(),
 	                    reception.getFireSituationRoom())) // fireSituationRoom 필드 추가
 	            .collect(Collectors.toList());

 		return ResponseEntity.ok(dtos);
 	}

 	// 모든 FireReception 데이터 조회
 	@GetMapping("/all")
 	public ResponseEntity<List<FireReceptionDto>> getAllFireReceptions() {
 	    List<FireReception> fireReceptions = fireReceptionRepository.findAll();
 	    List<FireReceptionDto> dtos = fireReceptions.stream()
 	            .map(reception -> new FireReceptionDto(reception.getNum(), reception.getUser().getHp(),
 	                    reception.getImgurl(), reception.getAdate(), reception.getGps(), reception.getProgress(),
 	                    reception.getFireSituationRoom())) // fireSituationRoom 필드 추가
 	            .collect(Collectors.toList());

 	    return ResponseEntity.ok(dtos);
 	}


}
