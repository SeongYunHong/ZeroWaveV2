// ResultRepository.java
package com.ZeroWaveV2.FireAlertV2.repository;

import com.ZeroWaveV2.FireAlertV2.model.Result;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ResultRepository extends JpaRepository<Result, Integer> {
	List<Result> findByFs(String fs);
}
