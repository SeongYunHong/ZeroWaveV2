import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { BrowserRouter, Routes, Route, Link, useLocation, useNavigate } from 'react-router-dom';
import Mainpage from './Mainpage/Mainpage';
import Mountain from './Mountain/Mountain';

import Notice from './Notice/Notice';
import NoticeDetail from './Notice/NoticeDetail';

import Subtitle from './Subtitle/Subtitle';

import Admin_Notice from './Admin_Notice/Admin_Notice';
import Admin_Notice_New from './Admin_Notice/Admin_Notice_New';
import Admin_Notice_Detail from './Admin_Notice/Admin_Notice_Detail';
import Admin_Notice_Update from './Admin_Notice/Admin_Notice_Update';

import Reception from './Reception/Reception';

import Mypage from './Mypage/Mypage';
import Signup from './Signup/Signup';

import Admin_Signup from './Signup/Admin_Signup';

import Fire_Signup from './Signup/Fire_Signup';

import Result from './Result/Result';

import Modal from './Modal/Modal';

import 'bootstrap/dist/css/bootstrap.min.css';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faBars, faTimes, faAngleRight } from '@fortawesome/free-solid-svg-icons';
import './style.css';
import './HYUN.css';

import logoImage from './static/logo.png';

const Navigation = ({ onOpenModal }) => {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [navActive, setNavActive] = useState(false);
  const [userRole, setUserRole] = useState('');
  const location = useLocation();
  const navigate = useNavigate();
  // 여기에 추가: 각 li의 on_sub 클래스 토글 상태를 관리하기 위한 상태
  const [activeSub, setActiveSub] = useState(null);

  useEffect(() => {
      const token = localStorage.getItem('token');
      const isLoggedIn = localStorage.getItem('isLoggedIn') === 'true';

      // 사용자 권한 불러오기
    if (isLoggedIn) {
      axios.get('http://localhost:8081/api/auth/role', {
        headers: {
          'Authorization': `Bearer ${token}`
        }      
      }).then(response => {
        const roles = response.data.roles;
        // 간단한 예시로, 첫 번째 권한만 사용합니다.
        setUserRole(roles[0]);
        setIsLoggedIn(true);
      }).catch(error => {
        if (error.response && error.response.status === 401) {
          // 토큰 만료 등 인증 오류 시 로그아웃 처리
          localStorage.removeItem('token');
          setIsLoggedIn(false);
          setUserRole('');
          navigate('/login'); // 로그인 페이지로 이동
        } else {
          console.error('권한 불러오기 실패:', error);
        }
      });
    }
    else {
      setIsLoggedIn(false);
      setUserRole('');
    }
  }, [navigate]);  

  const handleLogout = (event) => {
    event.preventDefault();
    localStorage.removeItem('token');
    localStorage.setItem('isLoggedIn', 'false');
    setIsLoggedIn(false);
    setUserRole('');
    setNavActive(!navActive);    
    navigate('/');
  };

  const toggleNav = () => {
    setNavActive(!navActive); // navActive 상태 토글
  };

  // li 클릭 이벤트 핸들러
  const toggleSub = (index) => {
    setActiveSub((prevActiveSub) => prevActiveSub === index ? null : index);
  };

  // 회원 정보 수정 버튼 클릭 이벤트 핸들러
  const handleOpenModalAndToggleNav = (event) => {
    toggleNav(); // navActive 상태 토글
    onOpenModal(); // 모달 열기 함수 호출
  };

  const showSubtitle = location.pathname !== "/";

  const menuConfig = [
    { label: "추천 등산로", path: "/mountain", visibleFor: ["LOGGED_OUT", "ROLE_USER", "ROLE_ADMIN"] },
    { label: "공지사항", path: "/notice", visibleFor: ["LOGGED_OUT", "ROLE_USER", "ROLE_FIRETEAM", "ROLE_ADMIN"] },
    { label: "로그인 & 회원가입", path: "/login", visibleFor: ["LOGGED_OUT"], action: toggleNav },
    { label: "회원 정보 수정", visibleFor: ["ROLE_USER"], action: handleOpenModalAndToggleNav },
    { label: "접수현황", path: "/reception", visibleFor: ["ROLE_FIRETEAM", "ROLE_ADMIN"] },
    { label: "로그아웃", visibleFor: ["ROLE_USER", "ROLE_FIRETEAM", "ROLE_ADMIN"], action: handleLogout },
  ];

  const renderMenuItems = () => {
    return menuConfig.filter(item => 
      (item.visibleFor.includes("LOGGED_OUT") && !isLoggedIn) ||
      (item.visibleFor.includes(userRole))
    ).map((item, index) => (
      <li key={index}>
        {item.path ? (
          <Link to={item.path} className="item" onClick={item.action || toggleNav}>
            <span>{item.label}</span>
            <FontAwesomeIcon className='icon1' icon={faAngleRight} />
          </Link>
        ) : (
          <button className='item' onClick={item.action}>
            <span>{item.label}</span>
            <FontAwesomeIcon className='icon1' icon={faAngleRight} />
          </button>
        )}
      </li>
    ));
  };
  
  return (
    <>
      <header id="header">
        <section className="containerV1">
          <div className="itemBox">
            <div className={`menuBox_bg ${navActive ? '' : 'hidden'}`} onClick={toggleNav}></div> {/* 조건부 클래스 적용 */}
            <h1 id="logo" className={`${navActive ? 'logo_hide' : ''}`}> {/* 조건부 클래스 적용 */}
              <Link to="/" className='logo'>
                <img src={logoImage} alt="로고" />
              </Link>
            </h1>
            {/* 모바일 열기 버튼 */}
            <div className="open_btn visible-sm visible-xs" onClick={toggleNav}> {/* 이벤트 핸들러 추가 */}
              <FontAwesomeIcon className='icon1' icon={faBars} />
            </div>
            <nav id="nav" className={`${navActive ? 'inactive' : ''}`}> {/* 조건부 클래스 적용 */}
              <div className="nav_inner">
                <div className="nav_topBox">
                  <Link to="/" className="nav_logo">모바일로고</Link>
                  {/* 모바일 닫기 버튼 */}
                  <div className="close_btn visible-sm visible-xs" onClick={toggleNav}>
                    <FontAwesomeIcon className='icon1' icon={faTimes} />
                  </div>
                </div>
                <ul className="outer">
                  {renderMenuItems()}
                </ul>
              </div>
            </nav>
          </div>
        </section>
      </header>
      {showSubtitle && <Subtitle />}
    </>
  );
};

function App() {
  const [showModal, setShowModal] = useState(false);

  const handleOpenModal = () => setShowModal(true);
  const handleCloseModal = () => setShowModal(false);




  return (
    <BrowserRouter>
      <Navigation onOpenModal={handleOpenModal} />
      {
        showModal && (
          <Modal onClose={handleCloseModal}>
            <Mypage onCloseModal={handleCloseModal} />
          </Modal>
        )
      }
      <div className="App">
        <Routes>
          <Route path="/" element={<Mainpage />} />
          <Route path="/mountain" element={<Mountain />} />
          <Route path="/notice" element={<Notice />} />
          <Route path="/notice/:noticeId" element={<NoticeDetail />} />
          <Route path="/admin/notice" element={<Admin_Notice />} />
          <Route path="/admin/notice/new" element={<Admin_Notice_New />} />
          <Route path="/admin/notice/:noticeId" element={<Admin_Notice_Detail />} />
          <Route path="/admin/notice/update/:noticeId" element={<Admin_Notice_Update />} />
          <Route path="/reception" element={<Reception />} />
          <Route path="/login" element={<Signup />} />
          <Route path="/admin/login" element={<Admin_Signup />} />
          <Route path="/fire/login" element={<Fire_Signup />} />
          <Route path="/fire/result" element={<Result />} />
        </Routes>
      </div>
    </BrowserRouter>
  );
}

export default App;