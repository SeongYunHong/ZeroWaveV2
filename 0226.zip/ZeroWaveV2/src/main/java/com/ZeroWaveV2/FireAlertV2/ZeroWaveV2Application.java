package com.ZeroWaveV2.FireAlertV2;


import java.io.IOException;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.core.io.ClassPathResource;
import com.google.auth.oauth2.GoogleCredentials;
import com.google.firebase.FirebaseApp;
import com.google.firebase.FirebaseOptions;

@SpringBootApplication
public class ZeroWaveV2Application {

	public static void main(String[] args) {
		SpringApplication.run(ZeroWaveV2Application.class, args);
//		initializeFirebaseAdmin();
	}

	
//	private static void initializeFirebaseAdmin() {
//        try {
//        	ClassPathResource serviceAccount = new ClassPathResource("firebase/final-project-firealert-firebase-adminsdk-ersl1-035933e277.json"); // JSON 키 파일 경로
//
//            FirebaseOptions options = new FirebaseOptions.Builder()
//                    .setCredentials(GoogleCredentials.fromStream(serviceAccount.getInputStream()))
//                    .setDatabaseUrl("https://final-project-firealert.firebaseio.com")
//                    .build();
//            
//            FirebaseApp.initializeApp(options);
//        } catch (IOException e) {
//            e.printStackTrace();
//        }
//    }
}
