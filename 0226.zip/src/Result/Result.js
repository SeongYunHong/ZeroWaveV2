import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import './Result.css';

function Result() {
    const [results, setResults] = useState([]);
    const navigate = useNavigate();

    useEffect(() => {
        const fetchUserRole = async () => {
            const token = localStorage.getItem('token');
            if (!token) {
                alert('소방팀만 접근할 수 있는 페이지입니다.');
                navigate('/');
                return;
            }
            try {
                const response = await axios.get('http://localhost:8081/api/auth/role', {
                    headers: {
                        'Authorization': `Bearer ${token}`
                    }
                });
                // 소방팀인지 확인
                if (!response.data.roles.includes('ROLE_FIRETEAM')) {
                    alert('소방팀만 접근할 수 있는 페이지입니다.');
                    navigate('/');
                    return;
                }
            } catch (error) {
                console.error('Role fetching failed', error);
                navigate('/');
            }
        };
        fetchUserRole();
    }, [navigate]);

    useEffect(() => {
        const fetchData = async () => {
            try {
                const response = await axios.get(`http://localhost:8081/api/fireSituationRoom`, {
                    headers: {
                        'Authorization': `Bearer ${localStorage.getItem('token')}`
                    }
                });
                setResults(response.data);
            } catch (error) {
                console.error('데이터를 가져오는데 실패했습니다.', error);
            }
        };

        fetchData();
    }, []);

    // imgurl 변환 함수
    const convertImageUrl = (relativeUrl) => {
        const baseUrl = "http://localhost:8081";
        const imagePath = relativeUrl.split("static")[1].replace(/\\/g, "/");
        return `${baseUrl}${imagePath}`;
    };

    // 날짜 포맷 변환 함수
    const formatDate = (dateString) => {
        return dateString.substring(0, 10);
    };

    const gotoResult = (command) => {
        navigate(`/fire/result/${command}`);
    };

    const gotoNewResult = (command) => {
        navigate(`/fire/result/new/${command}`);
    };

    const gotoUpdateResult = (command) => {
        navigate(`/fire/result/update/${command}`);
    };

    return (
        <div className="gallery">
            <div className="gallery-grid">
                {results.map((result, index) => (
                    <div className="gallery-item" key={index}>
                        <img src={convertImageUrl(result.imgurl)} alt={`Result ${index}`} onClick={() => gotoResult(result.command)} />
                        <div className="gallery-item-info">
                            <p>날짜: {formatDate(result.adate)}</p>
                            <p>위치: {result.gps}</p>
                            <p>진행 상태: {result.progress}</p>
                            {/* <button onClick={() => gotoNewResult(result.command)}>작성하기</button>
                            <button onClick={() => gotoUpdateResult(result.command)}>수정하기</button> */}
                        </div>
                    </div>
                ))}
            </div>
        </div>
    );
}

export default Result;