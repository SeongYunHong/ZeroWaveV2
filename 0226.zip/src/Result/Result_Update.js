import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useParams, useNavigate } from 'react-router-dom';

function Result_Update() {
    const { command } = useParams(); // URL에서 command 값을 추출
    const [resultData, setResultData] = useState({
        dtime: '',
        cdate: '',
        wtime: '',
        ff: 0,
        ftruck: 0,
        hc: 0,
        fw: 0,
        losses: 0,
        lmoney: 0,
        darea: 0,
    });
    const [results,setResults] = useState([]);
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState(null);
    const navigate = useNavigate();

    useEffect(() => {
        const fetchData = async () => {
            try {
                const response = await axios.get(`http://localhost:8081/api/fireSituationRoom`, {
                    headers: {
                        'Authorization': `Bearer ${localStorage.getItem('token')}`
                    }
                });
                setResults(response.data);
            } catch (error) {
                console.error('데이터를 가져오는데 실패했습니다.', error);
            }
        };

        fetchData();
    }, []);

    // useEffect(() => {
    //     const fetchData = async () => {
    //         setIsLoading(true);
    //         try {
    //             const response = await axios.get(`http://localhost:8081/api/result/${command}`);
    //             setResults(response.data);
    //         } catch (error) {
    //             console.error('데이터를 불러오는 데 실패했습니다.', error);
    //             setError('데이터를 불러오는 데 실패했습니다.');
    //         } finally {
    //             setIsLoading(false);
    //         }
    //     };

    //     fetchData();
    // }, [command]);

    const handleChange = (e) => {
        const { name, value } = e.target;
        setResultData(prevState => ({
            ...prevState,
            [name]: value,
        }));
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        setIsLoading(true);
        try {
            await axios.put(`http://localhost:8081/api/result/${command}`, resultData);
            alert('데이터가 성공적으로 수정되었습니다.');
            navigate('/'); // 수정 후 리다이렉트할 경로 설정
        } catch (error) {
            console.error('데이터 수정 실패', error);
            setError('데이터 수정 실패');
        } finally {
            setIsLoading(false);
        }
    };

    if (isLoading) return <div>Loading...</div>;
    if (error) return <div>Error: {error}</div>;

    // imgurl 변환 함수
    const convertImageUrl = (relativeUrl) => {
        const baseUrl = "http://localhost:8081";
        const imagePath = relativeUrl.split("static")[1].replace(/\\/g, "/");
        return `${baseUrl}${imagePath}`;
    };

    const gotoResult = () => {
        navigate(`/fire/result`);
    };

    return (
        <div className="Result" >
            <div className="Card">
                <h2>결과 상세 정보</h2>
                {results.map((result, index) => (
                    <img src={convertImageUrl(result.imgurl)} alt={`Result ${index}`} />
                ))}
                <form onSubmit={handleSubmit}>
                    <div><label>출동 시각: <input name="dtime" type="datetime-local" value={resultData.dtime} onChange={handleChange} /></label></div>
                    <div><label>종료 시간: <input name="cdate" type="datetime-local" value={resultData.cdate} onChange={handleChange} /></label></div>
                    <div><label>걸린 시간: <input name="wtime" type="text" value={resultData.wtime} readOnly /></label></div>
                    <div><label>출동 인원: <input name="ff" type="number" value={resultData.ff} onChange={handleChange} /></label></div>
                    <div><label>출동 소방차: <input name="ftruck" type="number" value={resultData.ftruck} onChange={handleChange} /></label></div>
                    <div><label>출동 헬기: <input name="hc" type="number" value={resultData.hc} onChange={handleChange} /></label></div>
                    <div><label>소화수: <input name="fw" type="number" value={resultData.fw} onChange={handleChange} /></label></div>
                    <div><label>사상자: <input name="losses" type="number" value={resultData.losses} onChange={handleChange} /></label></div>
                    <div><label>피해 금액: <input name="lmoney" type="number" value={resultData.lmoney} onChange={handleChange} /></label></div>
                    <div><label>피해 면적: <input name="darea" type="number" value={resultData.darea} onChange={handleChange} /></label></div>
                    <button type="submit">Submit</button>
                </form>
            </div>
            <button onClick={gotoResult()}>목록</button>
        </div>
    );
}

export default Result_Update;
