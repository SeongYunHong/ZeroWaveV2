import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import axios from 'axios';
import './Result_Detail.css'

function Result_Detail() {
    const { command } = useParams();
    const [informations, setInformations] = useState(null);
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState(null);
    const [results, setResults] = useState([]);
    const navigate = useNavigate();

    useEffect(() => {
        const fetchUserRole = async () => {
            const token = localStorage.getItem('token');
            if (!token) {
                alert('소방팀만 접근할 수 있는 페이지입니다.');
                navigate('/');
                return;
            }
            try {
                const response = await axios.get('http://localhost:8081/api/auth/role', {
                    headers: {
                        'Authorization': `Bearer ${token}`
                    }
                });
                // 소방팀인지 확인
                if (!response.data.roles.includes('ROLE_FIRETEAM')) {
                    alert('소방팀만 접근할 수 있는 페이지입니다.');
                    navigate('/');
                    return;
                }
            } catch (error) {
                console.error('Role fetching failed', error);
                navigate('/');
            }
        };
        fetchUserRole();
    }, [navigate]);

    useEffect(() => {
        const fetchData = async () => {
            try {
                const response = await axios.get(`http://localhost:8081/api/fireSituationRoom`, {
                    headers: {
                        'Authorization': `Bearer ${localStorage.getItem('token')}`
                    }
                });
                setResults(response.data);
            } catch (error) {
                console.error('데이터를 가져오는데 실패했습니다.', error);
            }
        };

        fetchData();
    }, []);

    // imgurl 변환 함수
    const convertImageUrl = (relativeUrl) => {
        const baseUrl = "http://localhost:8081";
        const imagePath = relativeUrl.split("static")[1].replace(/\\/g, "/");
        return `${baseUrl}${imagePath}`;
    };

    useEffect(() => {
        const fetchResultDetail = async () => {
            const token = localStorage.getItem('token'); // 토큰 가져오기
            try {
                const response = await fetch(`http://localhost:8081/api/result/${command}`);
                if (!response.ok) {
                    throw new Error('데이터를 가져오는 데 실패했습니다.');
                }
                const data = await response.json(); // 응답으로부터 JSON 추출
                setInformations(data); // 상태 업데이트
            } catch (error) {
                console.error('Error:', error);
                setError(error.message); // 에러 상태 업데이트
            }
        };
    
        fetchResultDetail();
    }, [command]);

    if (isLoading) return <div>Loading...</div>;
    if (error) return <div>Error: {error}</div>;
    if (!informations) return <div>No result found</div>;

    const formatDateAndTime = (isoString) => {
        const date = new Date(isoString);
        const year = date.getFullYear();
        const month = (date.getMonth() + 1).toString().padStart(2, '0');
        const day = date.getDate().toString().padStart(2, '0');
        const hours = date.getHours().toString().padStart(2, '0');
        const minutes = date.getMinutes().toString().padStart(2, '0');
        const seconds = date.getSeconds().toString().padStart(2, '0');

        return `${year}/${month}/${day} ${hours}시 ${minutes}분 ${seconds}초`;
    };

    const gotoResult = () => {
        navigate(`/fire/result`);
    };

    return (
        <div className="Result" >
            <div className="Card">
                <h2>결과 상세 정보</h2>
                {results.map((result, index) => (
                    <img src={convertImageUrl(result.imgurl)} alt={`Result ${index}`} />
                ))}
                <p>배치 ID: {informations.dispatch}</p>
                <p>출동 시각: {formatDateAndTime(informations.dtime)}</p>
                <p>종료 시간: {formatDateAndTime(informations.cdate)}</p>
                <p>걸린 시간: {informations.wtime}</p>
                <p>출동 인원: {informations.ff}</p>
                <p>출동 소방차 수: {informations.ftruck}</p>
                <p>출동 헬기 수: {informations.hc}</p>
                <p>소화수(L): {informations.fw}</p>
                <p>사상자: {informations.losses}</p>
                <p>피해 금액: {informations.lmoney}</p>
                <p>피해 면적: {informations.darea}</p>
            </div>
            <button onClick={gotoResult()}>목록</button>
        </div>
    );
}
export default Result_Detail;