import React, { useState } from 'react';
import { useParams } from 'react-router-dom';
import axios from 'axios';
import './Result_New.css';

function Result_New() {
    const { command } = useParams();
    const [result, setResult] = useState({
        command: command,
        dtime: '',
        cdate: '',
        wtime: '',
        ff: 0,
        ftruck: 0,
        hc: 0,
        fw: 0,
        losses: 0,
        lmoney: 0,
        darea: 0,
    });

    const handleChange = (e) => {
        const { name, value } = e.target;        
        let newValue = value;
        // 숫자 필드의 경우, 값을 숫자로 변환
        if (['ff', 'ftruck', 'hc', 'fw', 'losses', 'lmoney', 'darea'].includes(name)) {
            newValue = value ? parseInt(value, 10) : 0;
        }

        let newResult = { ...result, [name]: value };
        if (name === 'dtime' || name === 'cdate') {
            const dtimeValue = (name === 'dtime') ? value : result.dtime;
            const cdateValue = (name === 'cdate') ? value : result.cdate;

            if (dtimeValue && cdateValue) {
                const wtimeValue = calculateTimeDifference(dtimeValue, cdateValue);
                newResult = { ...newResult, wtime: wtimeValue };
            }
        }
        setResult(newResult);
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        // dtime과 cdate를 UTC로 변환
        const updatedResult = {
            ...result,
            dtime: convertToUTC(result.dtime),
            cdate: convertToUTC(result.cdate),
        };

        try {
            const response = await axios.post('http://localhost:8081/api/result', updatedResult);
            console.log(response.data);
            console.log("Sending data:", JSON.stringify(updatedResult));
            alert('제출되었습니다.');
        } catch (error) {
            console.error('Error posting result', error);
        }
    };

    const convertToUTC = (dateString) => {
        const date = new Date(dateString);
        const year = date.getUTCFullYear();
        const month = (date.getUTCMonth() + 1).toString().padStart(2, '0');
        const day = date.getUTCDate().toString().padStart(2, '0');
        const hours = date.getUTCHours().toString().padStart(2, '0');
        const minutes = date.getUTCMinutes().toString().padStart(2, '0');
        const seconds = date.getUTCSeconds().toString().padStart(2, '0');

        return `${year}-${month}-${day}T${hours}:${minutes}:${seconds}`;
    };

    const calculateTimeDifference = (start, end) => {
        const startDate = new Date(start);
        const endDate = new Date(end);
        const difference = endDate - startDate;

        const minutes = Math.floor(difference / (1000 * 60));
        const hours = Math.floor(minutes / 60);
        const remainingMinutes = minutes % 60;

        return `${hours}시간 ${remainingMinutes}분`;
    };

    return (
        <div className="Result" >
            <div className="Card">
                <form onSubmit={handleSubmit}>
                    <div><label>출동 시각: <input name="dtime" type="datetime-local" value={result.dtime} onChange={handleChange} /></label></div>
                    <div><label>종료 시간: <input name="cdate" type="datetime-local" value={result.cdate} onChange={handleChange} /></label></div>
                    <div><label>걸린 시간: <input name="wtime" type="text" value={result.wtime} readOnly /></label></div>
                    <div><label>출동 인원: <input name="ff" type="number" value={result.ff} onChange={handleChange} /></label></div>
                    <div><label>출동 소방차: <input name="ftruck" type="number" value={result.ftruck} onChange={handleChange} /></label></div>
                    <div><label>출동 헬기: <input name="hc" type="number" value={result.hc} onChange={handleChange} /></label></div>
                    <div><label>소화수: <input name="fw" type="number" value={result.fw} onChange={handleChange} /></label></div>
                    <div><label>사상자: <input name="losses" type="number" value={result.losses} onChange={handleChange} /></label></div>
                    <div><label>피해 금액: <input name="lmoney" type="number" value={result.lmoney} onChange={handleChange} /></label></div>
                    <div><label>피해 면적: <input name="darea" type="number" value={result.darea} onChange={handleChange} /></label></div>
                    <button type="submit">Submit</button>
                </form>
            </div>
        </div >
    );
}

export default Result_New;