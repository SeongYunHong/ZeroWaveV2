import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import axios from 'axios';
import './Notice.css'; // 공통 CSS 사용

const Notice = () => {
  const [notices, setNotices] = useState([]);
  const [currentPage, setCurrentPage] = useState(1);
  const [noticesPerPage] = useState(10);
  const [isAdmin, setIsAdmin] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    const fetchUserRole = async () => {
      const token = localStorage.getItem('token');
      if (token) {
        try {
          const response = await axios.get('http://localhost:8081/api/auth/role', {
            headers: {
              'Authorization': `Bearer ${token}`
            }
          });
          // 관리자인 경우만 isAdmin을 true로 설정
          setIsAdmin(response.data.roles.includes('ROLE_ADMIN'));
        } catch (error) {
          console.error('Role fetching failed', error);
        }
      }
    };

    fetchUserRole();
  }, []);
  
  // 0303 수정
  useEffect(() => {
    const fetchNotices = async () => {
      try {
        const response = await axios.get('http://localhost:8081/api/notice');
        // 정렬
        const sortedData = response.data.sort((a, b) => b.num - a.num);
        setNotices(sortedData);
      } catch (error) {
        console.error('공지사항 데이터를 불러오는 데 실패했습니다.', error);
      }
    };

    fetchNotices();
  }, []);
  // 0303 수정

  // 현재 페이지에서 표시할 공지사항 계산
  const indexOfLastNotice = currentPage * noticesPerPage;
  const indexOfFirstNotice = indexOfLastNotice - noticesPerPage;
  const currentNotices = notices.slice(indexOfFirstNotice, indexOfLastNotice);

  // 페이지 번호를 클릭했을 때 실행될 함수
  const paginate = (pageNumber) => setCurrentPage(pageNumber);

  // 전체 페이지 수 계산
  const pageNumbers = [];
  for (let i = 1; i <= Math.ceil(notices.length / noticesPerPage); i++) {
    pageNumbers.push(i);
  }

  // 0303 수정
  // 날짜 포맷 변환 함수
  const formatDate = (dateString) => {
    // 날짜 문자열에서 년, 월, 일을 추출합니다.
    const year = dateString.substring(0, 4);
    const month = dateString.substring(5, 7);
    const day = dateString.substring(8, 10);

    // 추출한 년, 월, 일을 'YYYY.MM.DD' 형식으로 결합합니다.
    return `${year}.${month}.${day}`;
  };
  // 0303 수정


  const write = () => {
    navigate('/notice/new');
  };

  return (
    <div className="notice-container">
      <div className="notice-list">
        <table className="notice-table">
          <thead>
            <tr>
              <th>번호</th>
              <th>제목</th>
              <th>작성일</th>
            </tr>
          </thead>
          <tbody>
            {currentNotices.map(notice => (
              <tr key={notice.num}>
                <td>{notice.num}</td>
                <td><Link to={`/notice/${notice.num}`}>{notice.title}</Link></td>
                <td>{formatDate(notice.createDate)}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      {isAdmin && (
        <div>
          <button onClick={write}>글 쓰기</button>
        </div>
      )}
      <div className="notice-pagination">
        {pageNumbers.map(number => (
          <button key={number} onClick={() => paginate(number)} className={currentPage === number ? 'active' : ''}>
            {number}
          </button>
        ))}
      </div>
    </div>
  );
};

export default Notice;
