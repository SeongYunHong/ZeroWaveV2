import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import './Notice_New.css'

const Notice_New = () => {
  const [title, setTitle] = useState('');
  const [post, setPost] = useState('');
  const [imgurl, setImgurl] = useState(null);
  const navigate = useNavigate();

  useEffect(() => {
    const fetchUserRole = async () => {
      const token = localStorage.getItem('token');
      if (!token) {
        alert('관리자만 접근할 수 있는 페이지입니다.');
        navigate('/');
        return;
      }

      try {
        const response = await axios.get('http://localhost:8081/api/auth/role', {
          headers: {
            'Authorization': `Bearer ${token}`
          }
        });
        // 관리자인지 확인
        if (!response.data.roles.includes('ROLE_ADMIN')) {
          alert('관리자만 접근할 수 있는 페이지입니다.');
          navigate('/');
          return;
        }
      } catch (error) {
        console.error('Role fetching failed', error);
        navigate('/');
      }
    };

    fetchUserRole();
  }, [navigate]);

  const handleSubmit = async (event) => {
    event.preventDefault();
    try {
      const formData = new FormData();
      formData.append('title', title);
      formData.append('post', post);
      formData.append('image', imgurl);

      // 공지사항 생성            
      await axios.post('http://localhost:8081/api/notice', formData, {
        headers: {
          'Content-Type': 'multipart/form-data',
        },
      });

      alert('공지사항이 성공적으로 작성되었습니다.');
      navigate('/notice');
    } catch (error) {
      console.error('공지사항 작성 실패', error);
      alert('공지사항 작성에 실패했습니다.');
    }
  };

  return (

    <form onSubmit={handleSubmit}>
      <div className='detail_form'>
        <label htmlFor="title">제목</label>
        <input type="text" value={title} onChange={(e) => setTitle(e.target.value)} placeholder="Title" />

        <label htmlFor="post">내용</label>
        <textarea value={post} onChange={(e) => setPost(e.target.value)} placeholder="Post"></textarea>

        <label htmlFor="file">이미지 첨부</label>
        <input type="file" onChange={(e) => setImgurl(e.target.files[0])} />

        <button type="submit">작성하기</button>
      </div>
    </form>

  );
}

export default Notice_New;
