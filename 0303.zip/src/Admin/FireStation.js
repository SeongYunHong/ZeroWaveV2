import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
// import './Admin_user.css';

function FireStation() {
  const [firestations, setFirestations] = useState([]);
  const navigate = useNavigate();

  useEffect(() => {
    const fetchFirestation = async () => {
      try {
        const response = await axios.get('http://localhost:8081/api/firestation');
        //console.log(response.data);
        setFirestations(response.data);
      } catch (error) {
        console.error('소방서 정보 데이터를 불러오는 데 실패했습니다.', error);
      }
    };

    fetchFirestation();
  }, []);  

  return (
    <div className="firestation-container">
      <div className="firestation-list">
        <table className="firestation-table">
          <thead>
            <tr>
              <th>소방서 이름</th>
              <th>주소</th>
              <th>소방서 연락처</th>
            </tr>
          </thead>
          <tbody>
            {firestations.map((firestation, index) => (
              <tr key={index}>
                <td>{firestation.fsName}</td>
                <td>{firestation.fsAdd}</td>
                <td>{firestation.fph}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

export default FireStation;
