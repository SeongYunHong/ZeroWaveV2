import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import './Admin_Reception.css';

import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faCirclePlus } from '@fortawesome/free-solid-svg-icons';

function Admin_FireReception() {
  const [receptions, setReceptions] = useState([]);
  const navigate = useNavigate();

  // 240228 수정
  const [messages, setMessages] = useState([]);

  // 240302 수정
  const [animate, setAnimate] = useState(false);

  useEffect(() => {
    const fetchUserRole = async () => {
      const token = localStorage.getItem('token');
      if (!token) {
        alert('관리자만 접근할 수 있는 페이지입니다.');
        navigate('/');
        return;
      }
      try {
        const response = await axios.get('http://localhost:8081/api/auth/role', {
          headers: {
            'Authorization': `Bearer ${token}`
          }
        });
        // 소방팀인지 확인
        if (!response.data.roles.includes('ROLE_ADMIN')) {
          alert('관리자만 접근할 수 있는 페이지입니다.');
          navigate('/');
          return;
        }
      } catch (error) {
        console.error('Role fetching failed', error);
        navigate('/');
      }
    };
    fetchUserRole();
  }, [navigate]);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await axios.get('http://localhost:8081/api/fireSituationRoom/admin', {
          headers: {
            'Authorization': `Bearer ${localStorage.getItem('token')}`
          }
        });
        console.log(response.data);
        setReceptions(response.data);
        setAnimate(true); // 필터링 후 애니메이션 상태를 true로 설정
        setTimeout(() => setAnimate(false), 500); // 애니메이션 지속시간 후 false로 설정
      } catch (error) {
        console.error('데이터를 가져오는데 실패했습니다.', error);
      }
    };

    fetchData();
  }, []);

  // imgurl 변환 함수
  const convertImageUrl = (relativeUrl) => {
    const baseUrl = "http://localhost:8081";
    const imagePath = relativeUrl.split("static")[1].replace(/\\/g, "/");
    return `${baseUrl}${imagePath}`;
  };

  // 날짜 포맷 변환 함수
  const formatDate = (dateString) => {
    // 날짜 문자열에서 년, 월, 일을 추출합니다.
    const year = dateString.substring(0, 4);
    const month = dateString.substring(5, 7);
    const day = dateString.substring(8, 10);

    // 추출한 년, 월, 일을 'YYYY.MM.DD' 형식으로 결합합니다.
    return `${year}.${month}.${day}`;
  };

  //------------------------------------------------------------------------------------------------------------------------------------------------------
  const gotoAdminResult = (command) => {
    navigate(`/admin/result/${command}`);
  };

  return (
    <div className="sub_frame containerV1">
      <section className={`result_gallery ${animate ? 'fade-in' : ''}`}>
        {receptions.length > 0 ? (
          receptions.map((reception, index) => (
            <div className="item" key={index}>
              <figure className='img' onClick={() => gotoAdminResult(reception.command)}>
                <img src={convertImageUrl(reception.imgurl)} alt={`Reception ${index}`} />
                <span className='hover_bg'><FontAwesomeIcon className="icon" icon={faCirclePlus} /></span>
              </figure>
              <div className="item-info textBox">
                <p className='addr'>{reception.address}</p>
                <div className='inner1'>
                  <p className='date'>{formatDate(reception.adate)}</p>
                  <span className='icon'>|</span>
                  <p className='state'>{reception.progress}</p>
                </div>
              </div>
            </div>
          ))
        ) : (
          <p>글이 없습니다.</p>
        )}
      </section>
    </div >
  );
  // 240302 수정
}

export default Admin_FireReception;