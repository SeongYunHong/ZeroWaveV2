import React, { useState, useEffect } from 'react';
import axios from 'axios';
import './Reception.css';

function Reception() {
  const [receptions, setReceptions] = useState([]);
  const [animate, setAnimate] = useState(false);

  const getAddressFromCoordinates = async (latitude, longitude) => {
    try {
      const response = await axios.get(`https://nominatim.openstreetmap.org/reverse?format=json&lat=${latitude}&lon=${longitude}&zoom=18&addressdetails=1`);
      return response.data.display_name;
    } catch (error) {
      console.error('주소 변환 중 오류:', error);
      return ''; // 오류 발생 시 빈 문자열 반환
    }
  };

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await axios.get('http://localhost:8081/api/fireReception', {
          headers: {
            'Authorization': `Bearer ${localStorage.getItem('token')}`
          }
        });
        const receptionsData = await Promise.all(response.data.map(async (reception) => {
          const gpsArray = reception.gps.split(',');
          if (gpsArray.length === 2) {
            const latitude = parseFloat(gpsArray[0]);
            const longitude = parseFloat(gpsArray[1]);
            if (!isNaN(latitude) && !isNaN(longitude)) {
              const address = await getAddressFromCoordinates(latitude, longitude);
              const parts = address.split(',').map(part => part.trim());
              const reorderedParts = [
                parts[4], parts[3], parts[2], parts[1]
              ];
              const reformattedAddress = reorderedParts.join(' ');
              return {
                ...reception,
                address: reformattedAddress, // 추가된 주소 정보
              };
            }
          }
          // 유효하지 않은 GPS 데이터 처리
          return {
            ...reception,
            address: '유효하지 않은 GPS 데이터', // 또는 다른 기본값 사용
          };
        }));
        setReceptions(receptionsData);
        setAnimate(true);
        setTimeout(() => setAnimate(false), 500);
      } catch (error) {
        console.error('데이터를 가져오는데 실패했습니다.', error);
      }
    };

    fetchData();
  }, []);

  // imgurl 변환 함수
  const convertImageUrl = (relativeUrl) => {
    const baseUrl = "http://localhost:8081";
    const imagePath = relativeUrl.split("static")[1].replace(/\\/g, "/");
    return `${baseUrl}${imagePath}`;
  };

  // 날짜 포맷 변환 함수
  const formatDate = (dateString) => {
    // 날짜 문자열에서 년, 월, 일을 추출합니다.
    const year = dateString.substring(0, 4);
    const month = dateString.substring(5, 7);
    const day = dateString.substring(8, 10);

    // 추출한 년, 월, 일을 'YYYY.MM.DD' 형식으로 결합합니다.
    return `${year}.${month}.${day}`;
};

  return (
    <div className="sub_frame containerV1">
      <section className={`reception_gallery ${animate ? 'fade-in' : ''}`}>
        {receptions.length > 0 ? (
          receptions.map((reception, index) => (
            <div className="item" key={index}>
              <figure className='img'><img src={convertImageUrl(reception.imgurl)} alt={`Reception ${index}`} /></figure>

              <div className="item-info textBox">
                <p className='addr'>{reception.address}</p>
                <div className='inner1'>
                  <p className='date'>{formatDate(reception.adate)}</p>
                  <span className='icon'>|</span>
                  <p className='state'>{reception.progress}</p>
                </div>
              </div>
            </div>
          ))
        ) : (
          <p>글이 없습니다.</p>
        )}
      </section>
    </div>
  );
}

export default Reception;