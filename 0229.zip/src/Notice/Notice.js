import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import axios from 'axios';
import './Notice.css'; // 공통 CSS 사용

const Notice = () => {
  const [notices, setNotices] = useState([]);
  const [isAdmin, setIsAdmin] = useState(false);
  const [showWriteButton, setShowWriteButton] = useState(false); // 글쓰기 버튼 보임 상태 관리
  const navigate = useNavigate();

  useEffect(() => {
    const fetchUserRole = async () => {
      const token = localStorage.getItem('token');
      if (token) {
        try {
          const response = await axios.get('http://localhost:8081/api/auth/role', {
            headers: {
              'Authorization': `Bearer ${token}`
            }
          });
          // 관리자인 경우만 isAdmin을 true로 설정
          setIsAdmin(response.data.roles.includes('ROLE_ADMIN'));
        } catch (error) {
          console.error('Role fetching failed', error);
        }
      }
    };

    fetchUserRole();
  }, []);

  useEffect(() => {
    const fetchNotices = async () => {
      try {
        const response = await axios.get('http://localhost:8081/api/notice');
        setNotices(response.data);
      } catch (error) {
        console.error('공지사항 데이터를 불러오는 데 실패했습니다.', error);
      }
    };

    fetchNotices();
  }, []);

  const write = () => {
    navigate('/admin/notice/new');
  };

  const toggleWriteButton = () => {
    setShowWriteButton(!showWriteButton); // 현재 상태의 반대로 설정
  };

  return (
    <div className="notice-container">
      <div className="notice-list">
        <table className="notice-table">
          <thead>
            <tr>
              <th>번호</th>
              <th>제목</th>
              <th>작성일</th>
            </tr>
          </thead>
          <tbody>
            {notices.map(notice => (
              <tr key={notice.num}>
                <td>{notice.num}</td>
                <td><Link to={`/notice/${notice.num}`}>{notice.title}</Link></td>
                <td>{new Date(notice.createDate).toLocaleDateString()}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      {isAdmin && (
        <div>
          <button onClick={toggleWriteButton}>글쓰기 버튼 토글</button>
          {showWriteButton && <button onClick={write}>글 쓰기</button>}
        </div>
      )}
    </div>
  );
};

export default Notice;
