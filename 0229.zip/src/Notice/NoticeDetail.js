import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useParams, useNavigate } from 'react-router-dom';
import './NoticeDetail.css';

const NoticeDetail = () => {
    const [detail, setDetail] = useState(null);
    const { noticeId } = useParams();
    const [isHitIncreased, setIsHitIncreased] = useState(false);
    const navigate = useNavigate();

    useEffect(() => {
        const fetchDetail = async () => {
            try {
                const detailResponse = await axios.get(`http://localhost:8081/api/notice/${noticeId}`);
                setDetail(detailResponse.data);
            } catch (error) {
                console.error('공지사항 세부 정보를 불러오는 데 실패했습니다.', error);
            }
        };
        fetchDetail();
    }, [noticeId]);

    useEffect(() => {
        if (detail && !isHitIncreased) {
            increaseHit();
            setIsHitIncreased(true);
        }
    }, [detail]);

    const increaseHit = async () => {
        try {
            await axios.get(`http://localhost:8081/api/notice/increaseHit/${noticeId}`);
        } catch (error) {
            console.error('공지사항 조회수 증가 중 오류 발생', error);
        }
    };

    if (!detail) {
        return <div className='notice_detail'>Loading...</div>;
    }

    const formattedDate = new Date(detail.createDate).toLocaleDateString('ko-KR', {
        year: 'numeric',
        month: 'long',
        day: 'numeric'
    });

    const convertImageUrl = (relativeUrl) => {
        const baseUrl = "http://localhost:8081";
        const imagePath = relativeUrl.split("static")[1].replace(/\\/g, "/");
        return `${baseUrl}${imagePath}`;
    };

    const gotoNotice = () => {
        navigate('/notice');
    };

    // 이전 및 다음 게시물 이동
    // const goToPrevNextNotice = async (direction) => {
    //     if (!detail.createDate) {
    //         console.error('createDate 정보가 없습니다.');
    //         return;
    //     }

    //     // createDate를 서버가 요구하는 형식으로 변환
    //     const createDate = new Date(detail.createDate);
    //     const formattedCreateDate = `${createDate.getFullYear()}/${String(createDate.getMonth() + 1).padStart(2, '0')}/${String(createDate.getDate()).padStart(2, '0')} ${String(createDate.getHours()).padStart(2, '0')}:${String(createDate.getMinutes()).padStart(2, '0')}:${String(createDate.getSeconds()).padStart(2, '0')}.${String(createDate.getMilliseconds()).padStart(3, '0')}`;

    //     try {
    //         const response = await axios.get(`http://localhost:8081/api/notice/${direction}/${encodeURIComponent(formattedCreateDate)}`);
    //         if (response.data) {
    //             console.log(response.data)
    //             navigate(`/notice/${response.data.num}`);
    //         } else {
    //             alert('더 이상 게시물이 없습니다.');
    //         }
    //     } catch (error) {
    //         console.error('게시물 이동 중 오류 발생', error);
    //     }
    // };



    return (
        <div className='notice_detail'>
            <h1>{detail.title}</h1>
            <div className="notice_info">
                <span>작성일: {formattedDate}</span>
                <span>조회수: {detail.hit}</span>
            </div>
            <div><img src={convertImageUrl(detail.imgurl)} alt="Notice" /></div>
            <div dangerouslySetInnerHTML={{ __html: detail.post }} />
            <div className="notice_navigation">
                {/* <button onClick={() => goToPrevNextNotice('previous')}>이전 게시물</button>
                <button onClick={() => goToPrevNextNotice('next')}>다음 게시물</button> */}
                <button onClick={gotoNotice}>목록으로</button>
            </div>
        </div>
    );
};

export default NoticeDetail;
