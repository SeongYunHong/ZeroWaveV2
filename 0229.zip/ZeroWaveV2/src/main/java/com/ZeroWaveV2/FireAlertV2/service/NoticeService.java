package com.ZeroWaveV2.FireAlertV2.service;

import java.sql.Timestamp;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ZeroWaveV2.FireAlertV2.dto.NoticeDto;
import com.ZeroWaveV2.FireAlertV2.model.Notice;
import com.ZeroWaveV2.FireAlertV2.repository.NoticeRepository;

@Service
public class NoticeService {
    @Autowired
    private NoticeRepository noticeRepository;

    public List<NoticeDto> findNoticeSummary() {
        return noticeRepository.findAll().stream().map(this::convertEntityToDto).collect(Collectors.toList());
    }
    
    // 공지사항 생성(Create)
    public NoticeDto createNotice(NoticeDto noticeDto) {
        Notice notice = new Notice();
        notice.setTitle(noticeDto.getTitle());
        notice.setPost(noticeDto.getPost());
        notice.setImgurl(noticeDto.getImgurl());
        Notice savedNotice = noticeRepository.save(notice);
        return convertEntityToDto(savedNotice);
    }
    
    // 공지사항 번호로 테이블 내에 있는 데이터 가져오기
    public NoticeDto getNoticeByNum(int num) {
    	Notice notice = noticeRepository.findByNum(num);
        if (notice != null) {
            return convertEntityToDto(notice);
        }
        return null;
    }

    private NoticeDto convertEntityToDto(Notice notice) {
    	NoticeDto noticeDTO = new NoticeDto();
        noticeDTO.setNum(notice.getNum());
        noticeDTO.setTitle(notice.getTitle());
        noticeDTO.setPost(notice.getPost());
        noticeDTO.setHit(notice.getHit());
        noticeDTO.setImgurl(notice.getImgurl());
        noticeDTO.setCreateDate(notice.getCreateDate());
        noticeDTO.setModifyDate(notice.getModifyDate());
        return noticeDTO;
    }
    
    // 수정
    public NoticeDto updateNotice(int num, NoticeDto noticeDto) {
        Notice existingNotice = noticeRepository.findByNum(num);
        if (existingNotice == null) {
            throw new RuntimeException("Notice not found for this num :: " + num);
        }
        existingNotice.setTitle(noticeDto.getTitle());
        existingNotice.setPost(noticeDto.getPost());
        existingNotice.setImgurl(noticeDto.getImgurl());
        Notice updatedNotice = noticeRepository.save(existingNotice);
        return convertEntityToDto(updatedNotice);
    }
    
    // 삭제
    public void deleteNotice(int num) {
        Notice notice = noticeRepository.findByNum(num);
        if (notice == null) {
            throw new RuntimeException("Notice not found for this num :: " + num);
        }
        noticeRepository.delete(notice);
    }
    
    // 조회 수 증가
    public void increaseNoticeHit(int num) {
    	Notice notice = noticeRepository.findByNum(num);
        notice.increaseHit();
        noticeRepository.save(notice); // 변경 감지를 통한 업데이트
    }
    
// // 이전 게시물 찾기
//    public NoticeDto findPreviousNotice(Timestamp createDate) {
//        Optional<Notice> notice = noticeRepository.findPreviousNotice(createDate);
//        if (notice.isPresent()) {
//            return convertEntityToDto(notice.get());
//        } else {
//            throw new NoSuchElementException("이전 게시물이 없습니다.");
//        }
//    }
//
//    // 다음 게시물 찾기
//    public NoticeDto findNextNotice(Timestamp createDate) {
//        Optional<Notice> notice = noticeRepository.findNextNotice(createDate);
//        if (notice.isPresent()) {
//            return convertEntityToDto(notice.get());
//        } else {
//            throw new NoSuchElementException("다음 게시물이 없습니다.");
//        }
//    }
}
