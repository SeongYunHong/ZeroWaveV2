package com.ZeroWaveV2.FireAlertV2.controller;

import com.ZeroWaveV2.FireAlertV2.constants.ErrorMessages;
import com.ZeroWaveV2.FireAlertV2.dto.ChangPasswordDto;
import com.ZeroWaveV2.FireAlertV2.dto.LoginDto;
import com.ZeroWaveV2.FireAlertV2.dto.UserRegistrationDto;
import com.ZeroWaveV2.FireAlertV2.jwt.JwtTokenProvider;
import com.ZeroWaveV2.FireAlertV2.repository.MemberRepository;
import com.ZeroWaveV2.FireAlertV2.service.MemberService;
import jakarta.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.*;


@RestController
@RequestMapping("/api")
public class MemberController {

	@Autowired
	private final MemberRepository memberRepository;
	
	@Autowired
    private final MemberService memberService;
	
	
    private final JwtTokenProvider jwtTokenProvider;

    public MemberController(MemberRepository memberRepository, MemberService memberService, JwtTokenProvider jwtTokenProvider) {
        this.memberRepository = memberRepository;
		this.memberService = memberService;
        this.jwtTokenProvider = jwtTokenProvider;
    }

    // 연락처 중복 검사
    @PostMapping("/check_hp")
    public ResponseEntity<?> checkId(@RequestBody Map<String, String> data) {
        String hp = data.get("hp");
        if (hp == null || hp.isBlank()) {
            return ResponseEntity.badRequest().body(Map.of("message", "연락처를 입력하세요."));
        }

        if (memberService.existsByHp(hp)) {
            return ResponseEntity.ok(Map.of("message", "이미 존재하는 연락처입니다.", "exists", true));
        } else {
            return ResponseEntity.ok(Map.of("message", "사용 가능한 연락처입니다.", "exists", false));
        }
    }

    // 회원가입
    @PostMapping("/register")
    public ResponseEntity<?> registerUser(@Valid @RequestBody UserRegistrationDto registrationDto) {
        var user = memberService.registerUser(
        		registrationDto.getHp(),
                registrationDto.getPassword(),
                registrationDto.getUserName());

        if (user != null) {
            return ResponseEntity.ok(user);
        } else {
            return ResponseEntity
                    .status(HttpStatus.CONFLICT)
                    .body(Map.of("error", ErrorMessages.USER_ALREADY_EXISTS));
        }
    }

    // 로그인
    @PostMapping("/login")
    public ResponseEntity<?> login(@Valid @RequestBody LoginDto loginDto) {
        var user = memberService.authenticate(loginDto.getHp(), loginDto.getPassword());
        if (user != null) {
        	List<String> roles = List.of("ROLE_USER");
        	long validityInMilliseconds = 3600000;
            var jwtToken = jwtTokenProvider.createToken(user.getHp(), roles, validityInMilliseconds);
            return ResponseEntity.ok(Map.of("token", jwtToken));
        } else {
            return ResponseEntity
                    .status(HttpStatus.UNAUTHORIZED)
                    .body(Map.of("error", ErrorMessages.AUTHENTICATION_FAILED));
        }
    }
    
    // 비밀번호 찾기
    @PutMapping("/find-password")
    public ResponseEntity<?> verifyAndChangePassword(@RequestBody ChangPasswordDto request) {
        if (memberService.verifyAndChangePassword(request.getHp(), request.getUsername(), request.getPassword())) {
            return ResponseEntity.ok().body("비밀번호 변경에 성공했습니다.");
        } else {
            return ResponseEntity.badRequest().body("사용자 검증 실패 또는 비밀번호 변경에 실패했습니다.");
        }
    }
}
