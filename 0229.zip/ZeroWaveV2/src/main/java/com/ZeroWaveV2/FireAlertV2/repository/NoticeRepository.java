package com.ZeroWaveV2.FireAlertV2.repository;

import java.sql.Timestamp;
import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.ZeroWaveV2.FireAlertV2.dto.NoticeDto;
import com.ZeroWaveV2.FireAlertV2.model.Notice;

public interface NoticeRepository extends JpaRepository<Notice, Integer> {
    @Query("SELECT new com.ZeroWaveV2.FireAlertV2.dto.NoticeDto(n.num, n.title, n.createDate) FROM Notice n")
    List<NoticeDto> findNoticeSummary();
        
    Notice findByNum(int num);
    
//    @Query(value = "SELECT * FROM (SELECT * FROM notice WHERE create_date > :createDate ORDER BY create_date ASC) WHERE ROWNUM = 1", nativeQuery = true)
//    Optional<Notice> findNextNotice(@Param("createDate") Timestamp createDate);
//
//    @Query(value = "SELECT * FROM (SELECT * FROM notice WHERE create_date < :createDate ORDER BY create_date DESC) WHERE ROWNUM = 1", nativeQuery = true)
//    Optional<Notice> findPreviousNotice(@Param("createDate") Timestamp createDate);
}
