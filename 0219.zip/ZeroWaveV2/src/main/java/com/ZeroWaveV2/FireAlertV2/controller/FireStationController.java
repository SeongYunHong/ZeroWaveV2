package com.ZeroWaveV2.FireAlertV2.controller;

import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ZeroWaveV2.FireAlertV2.constants.ErrorMessages;
import com.ZeroWaveV2.FireAlertV2.dto.FireStationDto;
import com.ZeroWaveV2.FireAlertV2.jwt.JwtTokenProvider;
import com.ZeroWaveV2.FireAlertV2.service.FireStationService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/firestation")
public class FireStationController {

	private final FireStationService fireStationService;
	private final JwtTokenProvider jwtTokenProvider;
	
	public FireStationController(FireStationService fireStationService, JwtTokenProvider jwtTokenProvider) {
        this.fireStationService = fireStationService;
        this.jwtTokenProvider = jwtTokenProvider;
    }
	
	// 로그인
    @PostMapping("/login")
    public ResponseEntity<?> login_firestation(@Valid @RequestBody FireStationDto fireStationDto) {
        var firestation = fireStationService.fireStation_login(fireStationDto.getFs(), fireStationDto.getPassword());
        if (firestation != null) {
            // Set token validity to 1 hour
            long validityInMilliseconds = 3600000;
            var jwtToken = jwtTokenProvider.createToken(firestation.getFs(), validityInMilliseconds);
            return ResponseEntity.ok(Map.of("token", jwtToken));
        } else {
            return ResponseEntity
                    .status(HttpStatus.UNAUTHORIZED)
                    .body(Map.of("error", ErrorMessages.AUTHENTICATION_FAILED));
        }
    }
}
