package com.ZeroWaveV2.FireAlertV2.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ZeroWaveV2.FireAlertV2.dto.FireReceptionDto;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.core.JsonProcessingException;
import org.springframework.http.HttpStatus;


@RestController
@RequestMapping("/api")
public class FireAlertController {
	@Autowired
	private KafkaTemplate<String, String> kafkaTemplate;

	@PostMapping("/firealert")
	public ResponseEntity<String> sendFireAlert(@RequestBody FireReceptionDto fireReceptionDto) {
	  try {
	    // ObjectMapper를 사용하여 FireReceptionDto 객체를 JSON 문자열로 변환
	    ObjectMapper objectMapper = new ObjectMapper();
	    String jsonMessage = objectMapper.writeValueAsString(fireReceptionDto);
	  
	    // Kafka로 메시지 전송
	    kafkaTemplate.send("firealert_topic", jsonMessage);
	  
	    // 응답 반환
	    return ResponseEntity.ok("메시지 전송 성공");
	  } catch (JsonProcessingException e) {
	    e.printStackTrace();
	    return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("메시지 전송 실패");
	  }
	}

}
