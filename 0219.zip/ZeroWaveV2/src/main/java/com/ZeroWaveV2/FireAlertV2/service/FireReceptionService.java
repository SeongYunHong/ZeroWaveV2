package com.ZeroWaveV2.FireAlertV2.service;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ZeroWaveV2.FireAlertV2.dto.FireReceptionDto;
import com.ZeroWaveV2.FireAlertV2.repository.FireReceptionRepository;

@Service
public class FireReceptionService {
    @Autowired
    private FireReceptionRepository fireReceptionRepository;

    public List<FireReceptionDto> findByHp(String hp) {
        return fireReceptionRepository.findByUser_Hp(hp).stream().map(entity -> {
            FireReceptionDto dto = new FireReceptionDto();
            dto.setImgurl(entity.getImgurl());
            dto.setGps(entity.getGps());
            dto.setProgress(entity.getProgress());
            dto.setAdate(entity.getAdate());
            return dto;
        }).collect(Collectors.toList());
    }
}
