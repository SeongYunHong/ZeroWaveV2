// const handleChangePassword = async () => {
//     if (newPassword !== confirmPassword) {
//       alert('새 비밀번호와 비밀번호 확인이 일치하지 않습니다.');
//       return;
//     }
//     if (newPassword == password) {
//       alert('변경하려는 비밀번호가 기존 비밀번호와 일치합니다.');
//       return;
//     }
//     try {
//       await axios.post('http://localhost:8081/api/mypage/update_pw', {
//         currentPassword,
//         newPassword,
//       }, {
//         headers: {
//           'Authorization': `Bearer ${localStorage.getItem('token')}`
//         }
//       });
//       alert('비밀번호가 변경되었습니다.');
//       setIsModalOpen(false); // 비밀번호 변경 후 모달 닫기
//     } catch (error) {
//       alert('비밀번호 변경 실패');
//       console.error(error);
//     }
//   };

//   <Modal isOpen={isOpen} onRequestClose={onRequestClose}>
//       <h2>회원 정보 수정</h2>
//       <div>
//         <input
//           type="password"
//           placeholder="현재 비밀번호"
//           value={currentPassword}
//           onChange={(e) => setCurrentPassword(e.target.value)}
//         />
//         <input
//           type="password"
//           placeholder="새 비밀번호"
//           value={newPassword}
//           onChange={(e) => setNewPassword(e.target.value)}
//         />
//         <input
//           type="password"
//           placeholder="새 비밀번호 확인"
//           value={confirmPassword}
//           onChange={(e) => setConfirmPassword(e.target.value)}
//         />
//         <button onClick={handleChangePassword}>비밀번호 변경</button>
//       </div>
//     </Modal>