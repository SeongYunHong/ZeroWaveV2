import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import './Signup.css'; // CSS 파일을 Signup.css로 가정

function Fire_Signup() {
    const [fs, setFs] = useState('');
    const [password, setPassword] = useState('');
    const navigate = useNavigate();

    // 입력 변경 핸들러
    const handleFireChange = (event) => {
        const { name, value } = event.target;
        switch (name) {
            case 'fs': setFs(value); break;
            case 'password': setPassword(value); break;
            default: break;
        }
    };

    // 페이지 배경색 설정
    useEffect(() => {
        const originalBackgroundColor = document.body.style.backgroundColor;
        document.body.style.backgroundColor = '#A8A8A8';
        return () => {
            document.body.style.backgroundColor = originalBackgroundColor;
        };
    }, []);

    // 로그인 처리
    const handleFireLogin = () => {
        axios.post('http://localhost:8081/api/firestation/login', { fs, password })
            .then(response => {
                const { token } = response.data;
                localStorage.setItem('token', token);
                localStorage.setItem('isLoggedIn', 'true');
                window.location.href = '/';
                alert('로그인에 성공하였습니다!');
            })
            .catch(error => {
                console.error('Login error:', error);
                if (error.response && error.response.status === 403) {
                    alert('아이디 또는 비밀번호가 잘못되었습니다.');
                } else {
                    alert('로그인 과정에서 오류가 발생했습니다.');
                }
            });
    };

    // Enter 키로 로그인 처리
    const handleFireKeyDown = (event) => {
        if (event.key === 'Enter') {
            handleFireLogin();
        }
    };

    return (
        <div className='login-container'>
            <div className="login-backbox">
                <div className={`loginMsg`}>
                    <div className="textcontent">
                        <p className="title">소방팀 전용 로그인 페이지</p>
                    </div>
                </div>
            </div>
            <div className={`login-frontbox`}>
                <div className={`login`}>
                    <h2>LOG IN</h2>
                    <div className="inputbox">
                        <input type="text" name="fs" placeholder="소방서 코드" value={fs} onChange={handleFireChange} />
                        <input type="password" name="password" placeholder="비밀번호" value={password} onChange={handleFireChange} onKeyDown={handleFireKeyDown} />
                    </div>
                    <button onClick={handleFireLogin}>LOG IN</button>
                </div>
            </div >
        </div>
    );
}

export default Fire_Signup;
