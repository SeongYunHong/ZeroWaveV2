import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useParams, useNavigate } from 'react-router-dom';

function Result_Update() {
    const { command } = useParams();
    const [resultData, setResultData] = useState({
        dtime: '',
        cdate: '',
        wtime: '',
        ff: 0,
        ftruck: 0,
        hc: 0,
        fw: 0,
        losses: 0,
        lmoney: 0,
        darea: 0,
    });
    const [informationss, setInformations] = useState([]);
    const [results, setResults] = useState([]);
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState(null);
    const navigate = useNavigate();
    //------------------------------------------------------------------------------------------------------------------------------------------------------
    useEffect(() => {
        const fetchUserRole = async () => {
            const token = localStorage.getItem('token');
            if (!token) {
                alert('소방팀만 접근할 수 있는 페이지입니다.');
                navigate('/');
                return;
            }
            try {
                const response = await axios.get('http://localhost:8081/api/auth/role', {
                    headers: {
                        'Authorization': `Bearer ${token}`
                    }
                });
                // 소방팀인지 확인
                if ((!response.data.roles.includes('ROLE_FIRETEAM'))&&!response.data.roles.includes('ROLE_ADMIN')) {
                    alert('소방팀만 접근할 수 있는 페이지입니다.');
                    navigate('/');
                    return;
                }
            } catch (error) {
                console.error('Role fetching failed', error);
                navigate('/');
            }
        };
        fetchUserRole();
    }, [navigate]);
    useEffect(() => {
        const fetchData = async () => {
            try {
                const response = await axios.get(`http://localhost:8081/api/fireSituationRoom`, {
                    headers: {
                        'Authorization': `Bearer ${localStorage.getItem('token')}`
                    }
                });
                // `useParams`에서 가져온 `command`가 문자열이라고 가정하고, 비교를 위해 숫자로 변환
                const commandNumber = parseInt(command, 10);
                // 응답 데이터를 필터링하여 command가 일치하는 항목만 포함
                const filteredResults = response.data.filter(item => item.command === commandNumber);
                setResults(filteredResults);
            } catch (error) {
                console.error('데이터를 가져오는데 실패했습니다.', error);
            }
        };

        fetchData();
    }, [command]);
    //------------------------------------------------------------------------------------------------------------------------------------------------------
    useEffect(() => {
        const fetchData = async () => {
            setIsLoading(true);
            try {
                const response = await axios.get(`http://localhost:8081/api/result/${command}`);
                setInformations(response.data);
            } catch (error) {
                console.error('데이터를 불러오는 데 실패했습니다.', error);
                setError('데이터를 불러오는 데 실패했습니다.');
            } finally {
                setIsLoading(false);
            }
        };

        fetchData();
    }, [command]);
    //------------------------------------------------------------------------------------------------------------------------------------------------------
    const handleChange = (e) => {
        const { name, value } = e.target;
        let newValue = value;
        // 숫자 필드의 경우, 값을 숫자로 변환
        if (['ff', 'ftruck', 'hc', 'fw', 'losses', 'lmoney', 'darea'].includes(name)) {
            newValue = value ? parseInt(value, 10) : 0;
        }

        let newResult = { ...resultData, [name]: value };
        if (name === 'dtime' || name === 'cdate') {
            const dtimeValue = (name === 'dtime') ? value : resultData.dtime;
            const cdateValue = (name === 'cdate') ? value : resultData.cdate;

            if (dtimeValue && cdateValue) {
                const wtimeValue = calculateTimeDifference(dtimeValue, cdateValue);
                newResult = { ...newResult, wtime: wtimeValue };
            }
        }
        setResultData(newResult);
    };
    //------------------------------------------------------------------------------------------------------------------------------------------------------
    const handleSubmit = async (e) => {
        e.preventDefault();
        // dtime과 cdate를 UTC로 변환
        const updatedResult = {
            ...resultData,
            dtime: convertToUTC(resultData.dtime),
            cdate: convertToUTC(resultData.cdate),
        };
        try {
            await axios.put(`http://localhost:8081/api/result/${command}`, updatedResult);
            alert('데이터가 성공적으로 수정되었습니다.');
            navigate('/fire/result'); // 수정 후 리다이렉트할 경로 설정
        } catch (error) {
            console.error('데이터 수정 실패', error);
            setError('데이터 수정 실패');
        } finally {
            setIsLoading(false);
        }
    };
    //------------------------------------------------------------------------------------------------------------------------------------------------------
    const convertToUTC = (dateString) => {
        const date = new Date(dateString);
        const year = date.getUTCFullYear();
        const month = (date.getUTCMonth() + 1).toString().padStart(2, '0');
        const day = date.getUTCDate().toString().padStart(2, '0');
        const hours = date.getUTCHours().toString().padStart(2, '0');
        const minutes = date.getUTCMinutes().toString().padStart(2, '0');
        const seconds = date.getUTCSeconds().toString().padStart(2, '0');

        return `${year}-${month}-${day}T${hours}:${minutes}:${seconds}`;
    };
    //------------------------------------------------------------------------------------------------------------------------------------------------------
    const calculateTimeDifference = (start, end) => {
        const startDate = new Date(start);
        const endDate = new Date(end);
        const difference = endDate - startDate;

        const minutes = Math.floor(difference / (1000 * 60));
        const hours = Math.floor(minutes / 60);
        const remainingMinutes = minutes % 60;

        return `${hours}시간 ${remainingMinutes}분`;
    };
    //------------------------------------------------------------------------------------------------------------------------------------------------------
    if (isLoading) return <div>Loading...</div>;
    if (error) return <div>Error: {error}</div>;
    //------------------------------------------------------------------------------------------------------------------------------------------------------
    // imgurl 변환 함수
    const convertImageUrl = (relativeUrl) => {
        const baseUrl = "http://localhost:8081";
        const imagePath = relativeUrl.split("static")[1].replace(/\\/g, "/");
        return `${baseUrl}${imagePath}`;
    };

    const gotoResult = () => {
        navigate(`/fire/result`);
    };
    //------------------------------------------------------------------------------------------------------------------------------------------------------
    return (
        <div className="Result" >
            <div className="Card">
                {/* {results.map((result, index) => (
                    <img key={index} src={convertImageUrl(result.imgurl)} alt={`Result ${index}`} />
                ))} */}
                <form onSubmit={handleSubmit}>
                    <div><label>출동 시각: <input name="dtime" type="datetime-local" value={resultData.dtime} onChange={handleChange} /></label></div>
                    <div><label>종료 시간: <input name="cdate" type="datetime-local" value={resultData.cdate} onChange={handleChange} /></label></div>
                    <div><label>걸린 시간: <input name="wtime" type="text" value={resultData.wtime} readOnly /></label></div>
                    <div><label>출동 인원: <input name="ff" type="number" value={resultData.ff} onChange={handleChange} /></label></div>
                    <div><label>출동 소방차: <input name="ftruck" type="number" value={resultData.ftruck} onChange={handleChange} /></label></div>
                    <div><label>출동 헬기: <input name="hc" type="number" value={resultData.hc} onChange={handleChange} /></label></div>
                    <div><label>소화수: <input name="fw" type="number" value={resultData.fw} onChange={handleChange} /></label></div>
                    <div><label>사상자: <input name="losses" type="number" value={resultData.losses} onChange={handleChange} /></label></div>
                    <div><label>피해 금액: <input name="lmoney" type="number" value={resultData.lmoney} onChange={handleChange} /></label></div>
                    <div><label>피해 면적: <input name="darea" type="number" value={resultData.darea} onChange={handleChange} /></label></div>
                    <button type="submit">Submit</button>
                </form>
            </div>
            <button onClick={gotoResult}>목록</button>
        </div>
    );
}

export default Result_Update;
