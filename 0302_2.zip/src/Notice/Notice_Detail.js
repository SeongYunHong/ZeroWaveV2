import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useParams, useNavigate } from 'react-router-dom';
import './Notice_Detail.css';

const Notice_Detail = () => {
    const [detail, setDetail] = useState(null);
    const { noticeId } = useParams();
    const [isHitIncreased, setIsHitIncreased] = useState(false);
    const [isAdmin, setIsAdmin] = useState(false);
    const navigate = useNavigate();

    useEffect(() => {
        const fetchUserRole = async () => {
            const token = localStorage.getItem('token');
            if (token) {
                try {
                    const response = await axios.get('http://localhost:8081/api/auth/role', {
                        headers: {
                            'Authorization': `Bearer ${token}`
                        }
                    });
                    // 관리자인 경우만 isAdmin을 true로 설정
                    setIsAdmin(response.data.roles.includes('ROLE_ADMIN'));
                } catch (error) {
                    console.error('Role fetching failed', error);
                }
            }
        };

        fetchUserRole();
    }, []);

    useEffect(() => {
        const fetchDetail = async () => {
            try {
                const detailResponse = await axios.get(`http://localhost:8081/api/notice/${noticeId}`);
                setDetail(detailResponse.data);
            } catch (error) {
                console.error('공지사항 세부 정보를 불러오는 데 실패했습니다.', error);
            }
        };
        fetchDetail();
    }, [noticeId]);

    useEffect(() => {
        if (detail && !isHitIncreased) {
            increaseHit();
            setIsHitIncreased(true);
        }
    }, [detail]);

    const increaseHit = async () => {
        try {
            await axios.get(`http://localhost:8081/api/notice/increaseHit/${noticeId}`);
        } catch (error) {
            console.error('공지사항 조회수 증가 중 오류 발생', error);
        }
    };

    if (!detail) {
        return <div className='notice_detail'>Loading...</div>;
    }

    const formattedDate = new Date(detail.createDate).toLocaleDateString('ko-KR', {
        year: 'numeric',
        month: 'long',
        day: 'numeric'
    });

    const convertImageUrl = (relativeUrl) => {
        const baseUrl = "http://localhost:8081";
        const imagePath = relativeUrl.split("static")[1].replace(/\\/g, "/");
        return `${baseUrl}${imagePath}`;
    };

    const gotoNotice = () => {
        navigate('/notice');
    };

    const updateNotice = () => {
        navigate(`/notice/update/${noticeId}`);
    }

    const deleteNotice = async () => {
        const confirmation = window.confirm('게시물을 삭제하시겠습니까?');
        if (!confirmation) {
            return;
        }

        try {
            const response = await axios.delete(`http://localhost:8081/api/notice/${noticeId}`);
            alert('게시물이 성공적으로 삭제되었습니다.');
            navigate('/notice');
        } catch (error) {
            console.error('게시물 삭제 실패', error);
            alert('게시물 삭제 중 문제가 발생했습니다.');
        }

    }

    // 이전 및 다음 게시물 이동
    const goToPrevNextNotice = async (direction) => {
        try {
            const response = await axios.get(`http://localhost:8081/api/notice/${direction}/${noticeId}`);
            console.log(response.data);
            if (response.data) {
                navigate(`/notice/${response.data.num}`);
            } else {
                alert('더 이상 게시물이 없습니다.');
            }
        } catch (error) {
            console.error('게시물 이동 중 오류 발생', error);
        }
    };



    return (
        <div className='notice_detail'>
            <h1>{detail.title}</h1>
            <div className="notice_info">
                <span>작성일: {formattedDate}</span>
                <span>조회수: {detail.hit}</span>
            </div>
            <div><img src={convertImageUrl(detail.imgurl)} alt="Notice" /></div>
            <div dangerouslySetInnerHTML={{ __html: detail.post }} />
            <div className="notice_navigation">
                <button onClick={() => goToPrevNextNotice('previous')}>이전 게시물</button>
                <button onClick={() => goToPrevNextNotice('next')}>다음 게시물</button>
                {isAdmin && (
                    <button onClick={updateNotice}>수정</button>
                )}
                {isAdmin && (
                    <button onClick={deleteNotice}>삭제</button>
                )}
                <button onClick={gotoNotice}>목록으로</button>
            </div>
        </div>
    );
};

export default Notice_Detail;
