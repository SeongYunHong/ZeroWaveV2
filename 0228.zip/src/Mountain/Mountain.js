import React, { useState, useEffect } from 'react';
import axios from 'axios';

function Mountain() {
  const [filtermountain, setFilteredMountains] = useState([]);
  const [mountains, setMountains] = useState([]);
  const [addresses, setAddresses] = useState([]);
  const [seasons, setSeasons] = useState([]);
  const [mtTimes, setMtTimes] = useState([]);
  const [filter, setFilter] = useState({
    address: '',
    season: '',
    mttime: '',
    minHeight: '',
    maxHeight: '',
  });

  useEffect(() => {
    const fetchMountains = async () => {
      try {
        const response = await axios.get('http://localhost:8081/api/mountain');
        setMountains(response.data);
        setFilteredMountains(response.data); // 초기에는 모든 데이터를 표시
      } catch (error) {
        console.error('Error fetching data: ', error);
      }
    };

    const fetchDataLists = async () => {
      try {
        const addressesResponse = await axios.get('http://localhost:8081/api/mountain/addresses');
        setAddresses(addressesResponse.data);

        const seasonsResponse = await axios.get('http://localhost:8081/api/mountain/seasons');
        setSeasons(seasonsResponse.data);

        const mtTimesResponse = await axios.get('http://localhost:8081/api/mountain/mttimes');
        setMtTimes(mtTimesResponse.data);
      } catch (error) {
        console.error('Error fetching lists: ', error);
      }
    };

    fetchMountains();
    fetchDataLists();
  }, []);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFilter(prev => ({ ...prev, [name]: value }));
  };

  useEffect(() => {
    const fetchFilteredMountains = async () => {
      try {
        // 빈 문자열 필터 제거
        const activeFilters = Object.fromEntries(Object.entries(filter).filter(([_, value]) => value !== ''));
        const queryParams = new URLSearchParams(activeFilters).toString();
        const url = `http://localhost:8081/api/mountain/filter?${queryParams}`;
        console.log('Requesting URL:', url); // 요청 URL 로그 출력
        const response = await axios.get(url);
        setMountains(response.data);
      } catch (error) {
        console.error('Error fetching filtered mountains:', error);
      }
    };

    fetchFilteredMountains();
  }, [filter]);


  // imgurl 변환 함수
  const convertImageUrl = (relativeUrl) => {
    const baseUrl = "http://localhost:8081";
    const imagePath = relativeUrl.split("static")[1].replace(/\\/g, "/");
    return `${baseUrl}${imagePath}`;
  };

  return (
    <div>
      <div>
        <label>위치:</label>
        <select name="address" onChange={handleChange} value={filter.address}>
          <option value="">전체</option>
          {addresses.map((address, index) => (
            <option key={index} value={address}>{address}</option>
          ))}
        </select>
      </div>
      <div>
        <label>계절:</label>
        <select name="season" onChange={handleChange} value={filter.season}>
          <option value="">전체</option>
          {seasons.map((season, index) => (
            <option key={index} value={season}>{season}</option>
          ))}
        </select>
      </div>
      <div>
        <label>등산 시간:</label>
        <select name="mttime" onChange={handleChange} value={filter.mttime}>
          <option value="">전체</option>
          {mtTimes.map((mttime, index) => (
            <option key={index} value={mttime}>{mttime}</option>
          ))}
        </select>
      </div>
      <div>
        <label>최소 높이:</label>
        <input type="number" name="minHeight" value={filter.minHeight} onChange={handleChange} />
      </div>
      <div>
        <label>최대 높이:</label>
        <input type="number" name="maxHeight" value={filter.maxHeight} onChange={handleChange} />
      </div>
      <ul>
        {mountains.length > 0 ? (
          mountains.map((mountain, index) => (
            <div key={index}>
              <img src={convertImageUrl(mountain.imgurl)} alt={mountain.mt} style={{ width: "100px", height: "100px" }} />
              <h2>{mountain.mt}</h2>
              <p>주소: {mountain.address}</p>
              <p>높이: {mountain.height}</p>
              <p>추천 계절: {mountain.season}</p>
              <p>소요 시간: {mountain.mttime}</p>
              <p>소개: {mountain.mtpost}</p>
            </div>
          ))
        ) : (
          <p>검색 결과가 없습니다.</p>
        )}
      </ul>
    </div>
  );
}

export default Mountain;
