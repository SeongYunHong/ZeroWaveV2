import React from 'react';
import axios from 'axios';

function UserDelete() {
  const handleDeleteAccount = async () => {
    if (window.confirm('정말로 탈퇴하시겠습니까?')) {
      try {
        await axios.delete('/api/user/delete');
        alert('회원 탈퇴가 완료되었습니다.');
        // 로그아웃 처리 및 로그인 페이지로 이동 등의 추가 처리 필요
      } catch (error) {
        alert('회원 탈퇴 실패');
        console.error(error);
      }
    }
  };

  return (
    <div>
      <button onClick={handleDeleteAccount}>회원 탈퇴</button>
    </div>
  );
}

export default UserDelete;
