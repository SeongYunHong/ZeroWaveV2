package com.ZeroWaveV2.FireAlertV2;


import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ZeroWaveV2Application {

	public static void main(String[] args) {
		SpringApplication.run(ZeroWaveV2Application.class, args);
	}	
}
