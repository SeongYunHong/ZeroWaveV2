package com.ZeroWaveV2.FireAlertV2.config;

import com.ZeroWaveV2.FireAlertV2.model.Mountain_recommend;
import com.ZeroWaveV2.FireAlertV2.repository.MountainRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.util.Arrays;
import java.util.List;

@Component
public class MountainInitializer implements CommandLineRunner {

    @Autowired
    private MountainRepository mountainRepository;

    @Override
    public void run(String... args) throws Exception {
        List<Mountain_recommend> mountains = Arrays.asList(
        		new Mountain_recommend("감악산", "경기도",	674, "매우 쉬움", "src\\main\\resources\\static\\mountain_images\\mt_ 1"),
        		new Mountain_recommend("관악산", "서울시",	629, "어려움", "src\\main\\resources\\static\\mountain_images\\mt_ 2"),
        		new Mountain_recommend("명지산", "경기도",	1267, "보통", "src\\main\\resources\\static\\mountain_images\\mt_ 3"),
        		new Mountain_recommend("소요산", "경기도",	587, "보통", "src\\main\\resources\\static\\mountain_images\\mt_ 4"),
        		new Mountain_recommend("연인산", "경기도",	1068, "매우 쉬움", "src\\main\\resources\\static\\mountain_images\\mt_ 5"),
        		new Mountain_recommend("용문산", "경기도",	1157, "매우 쉬움", "src\\main\\resources\\static\\mountain_images\\mt_ 6"),
        		new Mountain_recommend("운악산(동봉)", "경기도",	936, "쉬움", "src\\main\\resources\\static\\mountain_images\\mt_ 7"),
        		new Mountain_recommend("운악산(서봉)", "경기도",	936, "쉬움", "src\\main\\resources\\static\\mountain_images\\mt_ 8"),
        		new Mountain_recommend("유명산", "경기도",	862, "매우 쉬움", "src\\main\\resources\\static\\mountain_images\\mt_ 9"),
        		new Mountain_recommend("천마산", "경기도",	812, "쉬움", "src\\main\\resources\\static\\mountain_images\\mt_10"),
        		new Mountain_recommend("청계산", "서울시",	582, "매우 쉬움", "src\\main\\resources\\static\\mountain_images\\mt_11"),
        		new Mountain_recommend("화악산", "경기도",	1446, "어려움", "src\\main\\resources\\static\\mountain_images\\mt_12"),
        		new Mountain_recommend("도봉산", "서울시",	740, "매우 어려움", "src\\main\\resources\\static\\mountain_images\\mt_13"),
        		new Mountain_recommend("북한산", "서울시",	837, "어려움", "src\\main\\resources\\static\\mountain_images\\mt_14"),
        		new Mountain_recommend("수락산", "서울시",	640, "보통", "src\\main\\resources\\static\\mountain_images\\mt_15"),
        		new Mountain_recommend("마니산", "인천시",	472, "매우 쉬움", "src\\main\\resources\\static\\mountain_images\\mt_16"),
        		new Mountain_recommend("가리산", "강원도",	1051, "보통", "src\\main\\resources\\static\\mountain_images\\mt_17"),
        		new Mountain_recommend("가리왕산", "강원도",	1561, "어려움", "src\\main\\resources\\static\\mountain_images\\mt_18"),
        		new Mountain_recommend("감악산(원주)", "강원도",	945, "매우 쉬움", "src\\main\\resources\\static\\mountain_images\\mt_19"),
        		new Mountain_recommend("계방산", "강원도",	1577, "어려움", "src\\main\\resources\\static\\mountain_images\\mt_20"),
        		new Mountain_recommend("덕항산", "강원도",	1071, "어려움", "src\\main\\resources\\static\\mountain_images\\mt_21"),
        		new Mountain_recommend("두타산", "강원도",	1353, "어려움", "src\\main\\resources\\static\\mountain_images\\mt_22"),
        		new Mountain_recommend("방태산", "강원도",	1444, "어려움", "src\\main\\resources\\static\\mountain_images\\mt_23"),
        		new Mountain_recommend("백덕산", "강원도",	1350, "어려움", "src\\main\\resources\\static\\mountain_images\\mt_24"),
        		new Mountain_recommend("백운산(동강)", "강원도",	882, "보통", "src\\main\\resources\\static\\mountain_images\\mt_25"),
        		new Mountain_recommend("삼악산", "강원도",	654, "매우 쉬움", "src\\main\\resources\\static\\mountain_images\\mt_26"),
        		new Mountain_recommend("설악산", "강원도",	1708, "어려움", "src\\main\\resources\\static\\mountain_images\\mt_27"),
        		new Mountain_recommend("오대산(노인봉)", "강원도",	1338, "보통", "src\\main\\resources\\static\\mountain_images\\mt_28"),
        		new Mountain_recommend("오대산(비로봉)", "강원도",	1565, "보통", "src\\main\\resources\\static\\mountain_images\\mt_29"),
        		new Mountain_recommend("오봉산", "강원도",	779, "매우 쉬움", "src\\main\\resources\\static\\mountain_images\\mt_30"),
        		new Mountain_recommend("용화산", "강원도",	874, "매우 쉬움", "src\\main\\resources\\static\\mountain_images\\mt_31"),
        		new Mountain_recommend("치악산", "강원도",	1288, "어려움", "src\\main\\resources\\static\\mountain_images\\mt_32"),
        		new Mountain_recommend("태백산", "강원도",	1567, "보통", "src\\main\\resources\\static\\mountain_images\\mt_33"),
        		new Mountain_recommend("태화산", "강원도",	1027, "어려움", "src\\main\\resources\\static\\mountain_images\\mt_34"),
        		new Mountain_recommend("팔봉산", "강원도",	327, "매우 쉬움", "src\\main\\resources\\static\\mountain_images\\mt_35"),
        		new Mountain_recommend("함백산", "강원도",	1573, "보통", "src\\main\\resources\\static\\mountain_images\\mt_36"),
        		new Mountain_recommend("구병산", "충청북도",	877, "쉬움", "src\\main\\resources\\static\\mountain_images\\mt_37"),
        		new Mountain_recommend("금수산", "충청북도",	1016, "보통", "src\\main\\resources\\static\\mountain_images\\mt_38"),
        		new Mountain_recommend("도락산", "충청북도",	964, "매우 쉬움", "src\\main\\resources\\static\\mountain_images\\mt_39"),
        		new Mountain_recommend("민주지산", "충청북도",	1241, "매우 쉬움", "src\\main\\resources\\static\\mountain_images\\mt_40"),
        		new Mountain_recommend("소백산", "충청북도",	1440, "보통", "src\\main\\resources\\static\\mountain_images\\mt_41"),
        		new Mountain_recommend("속리산", "충청북도",	1057, "쉬움", "src\\main\\resources\\static\\mountain_images\\mt_42"),
        		new Mountain_recommend("월악산", "충청북도",	1097, "매우 어려움", "src\\main\\resources\\static\\mountain_images\\mt_43"),
        		new Mountain_recommend("조령산", "충청북도",	1026, "어려움", "src\\main\\resources\\static\\mountain_images\\mt_44"),
        		new Mountain_recommend("주흘산(영봉)", "충청북도",	1106, "어려움", "src\\main\\resources\\static\\mountain_images\\mt_45"),
        		new Mountain_recommend("주흘산(주봉)", "충청북도",	1106, "어려움", "src\\main\\resources\\static\\mountain_images\\mt_46"),
        		new Mountain_recommend("천태산", "충청북도",	714, "어려움", "src\\main\\resources\\static\\mountain_images\\mt_47"),
        		new Mountain_recommend("청화산", "충청북도",	970, "쉬움", "src\\main\\resources\\static\\mountain_images\\mt_48"),
        		new Mountain_recommend("칠보산", "충청북도",	778, "매우 쉬움", "src\\main\\resources\\static\\mountain_images\\mt_49"),
        		new Mountain_recommend("가야산(충남)", "충청남도",	678, "매우 쉬움", "src\\main\\resources\\static\\mountain_images\\mt_50"),
        		new Mountain_recommend("계룡산", "충청남도",	766, "보통", "src\\main\\resources\\static\\mountain_images\\mt_51"),
        		new Mountain_recommend("광덕산", "충청남도",	699, "매우 쉬움", "src\\main\\resources\\static\\mountain_images\\mt_52"),
        		new Mountain_recommend("오서산", "충청남도",	791, "보통", "src\\main\\resources\\static\\mountain_images\\mt_53"),
        		new Mountain_recommend("용봉산", "충청남도",	381, "쉬움", "src\\main\\resources\\static\\mountain_images\\mt_54"),
        		new Mountain_recommend("칠갑산", "충청남도",	561, "매우 쉬움", "src\\main\\resources\\static\\mountain_images\\mt_55"),
        		new Mountain_recommend("가야산(경상)", "경상북도",	1430, "매우 쉬움", "src\\main\\resources\\static\\mountain_images\\mt_56"),
        		new Mountain_recommend("금오산", "경상북도",	977, "어려움", "src\\main\\resources\\static\\mountain_images\\mt_57"),
        		new Mountain_recommend("내연산", "경상북도",	711, "매우 쉬움", "src\\main\\resources\\static\\mountain_images\\mt_58"),
        		new Mountain_recommend("대야산", "경상북도",	931, "쉬움", "src\\main\\resources\\static\\mountain_images\\mt_59"),
        		new Mountain_recommend("응봉산", "경상북도",	998, "어려움", "src\\main\\resources\\static\\mountain_images\\mt_60"),
        		new Mountain_recommend("주왕산", "경상북도",	721, "매우 쉬움", "src\\main\\resources\\static\\mountain_images\\mt_61"),
        		new Mountain_recommend("청량산", "경상북도",	870, "매우 쉬움", "src\\main\\resources\\static\\mountain_images\\mt_62"),
        		new Mountain_recommend("팔공산", "경상북도",	1193, "매우 쉬움", "src\\main\\resources\\static\\mountain_images\\mt_63"),
        		new Mountain_recommend("황악산", "경상북도",	1111, "쉬움", "src\\main\\resources\\static\\mountain_images\\mt_64"),
        		new Mountain_recommend("가지산", "경상남도",	1241, "매우 어려움", "src\\main\\resources\\static\\mountain_images\\mt_65"),
        		new Mountain_recommend("남산", "경상남도", 468, "매우 어려움", "src\\main\\resources\\static\\mountain_images\\mt_66"),
        		new Mountain_recommend("비슬산", "경상남도",	1084, "매우 쉬움", "src\\main\\resources\\static\\mountain_images\\mt_67"),
        		new Mountain_recommend("신불산", "경상남도",	1159, "어려움", "src\\main\\resources\\static\\mountain_images\\mt_68"),
        		new Mountain_recommend("재약산", "경상남도",	1189, "매우 쉬움", "src\\main\\resources\\static\\mountain_images\\mt_69"),
        		new Mountain_recommend("지리산", "경상남도",	1915, "매우 어려움", "src\\main\\resources\\static\\mountain_images\\mt_70"),
        		new Mountain_recommend("천성산", "경상남도",	855, "쉬움", "src\\main\\resources\\static\\mountain_images\\mt_71"),
        		new Mountain_recommend("천성산(비로봉)", "경상남도",	922, "쉬움", "src\\main\\resources\\static\\mountain_images\\mt_72"),
        		new Mountain_recommend("화왕산", "경상남도",	756, "매우 쉬움", "src\\main\\resources\\static\\mountain_images\\mt_73"),
        		new Mountain_recommend("황매산", "경상남도",	1108, "매우 쉬움", "src\\main\\resources\\static\\mountain_images\\mt_74"),
        		new Mountain_recommend("황석산", "경상남도",	1192, "매우 쉬움", "src\\main\\resources\\static\\mountain_images\\mt_75"),
        		new Mountain_recommend("구봉산", "전라북도",	1002, "쉬움", "src\\main\\resources\\static\\mountain_images\\mt_76"),
        		new Mountain_recommend("내변산", "전라북도",	424, "보통", "src\\main\\resources\\static\\mountain_images\\mt_77"),
        		new Mountain_recommend("대둔산", "전라북도",	878, "어려움", "src\\main\\resources\\static\\mountain_images\\mt_78"),
        		new Mountain_recommend("덕유산", "전라북도",	1614, "매우 쉬움", "src\\main\\resources\\static\\mountain_images\\mt_79"),
        		new Mountain_recommend("마이산(비룡대)", "전라북도",	686, "매우 쉬움", "src\\main\\resources\\static\\mountain_images\\mt_80"),
        		new Mountain_recommend("마이산(암마이봉)", "전라북도",	686, "매우 쉬움", "src\\main\\resources\\static\\mountain_images\\mt_81"),
        		new Mountain_recommend("모악산", "전라북도",	793, "쉬움", "src\\main\\resources\\static\\mountain_images\\mt_82"),
        		new Mountain_recommend("선운산", "전라북도",	336, "매우 쉬움", "src\\main\\resources\\static\\mountain_images\\mt_83"),
        		new Mountain_recommend("운장산", "전라북도",	1126, "매우 어려움", "src\\main\\resources\\static\\mountain_images\\mt_84"),
        		new Mountain_recommend("장안산", "전라북도",	1237, "매우 쉬움", "src\\main\\resources\\static\\mountain_images\\mt_85"),
        		new Mountain_recommend("지리산(바래봉)", "전라북도",	1165, "어려움", "src\\main\\resources\\static\\mountain_images\\mt_86"),
        		new Mountain_recommend("지리산(반야봉)", "전라북도",	1732, "매우 어려움", "src\\main\\resources\\static\\mountain_images\\mt_87"),
        		new Mountain_recommend("달마산", "전라남도",	489, "매우 쉬움", "src\\main\\resources\\static\\mountain_images\\mt_88"),
        		new Mountain_recommend("덕룡산(동봉)", "전라남도",	432, "매우 쉬움", "src\\main\\resources\\static\\mountain_images\\mt_89"),
        		new Mountain_recommend("덕룡산(서봉)", "전라남도",	432, "매우 쉬움", "src\\main\\resources\\static\\mountain_images\\mt_90"),
        		new Mountain_recommend("동악산", "전라남도",	735, "쉬움", "src\\main\\resources\\static\\mountain_images\\mt_91"),
        		new Mountain_recommend("두륜산", "전라남도",	703, "매우 쉬움", "src\\main\\resources\\static\\mountain_images\\mt_92"),
        		new Mountain_recommend("불갑산", "전라남도",	516, "매우 쉬움", "src\\main\\resources\\static\\mountain_images\\mt_93"),
        		new Mountain_recommend("월출산", "전라남도",	809, "매우 어려움", "src\\main\\resources\\static\\mountain_images\\mt_94"),
        		new Mountain_recommend("천관산", "전라남도",	724, "매우 쉬움", "src\\main\\resources\\static\\mountain_images\\mt_95"),
        		new Mountain_recommend("축령산", "전라남도",	621, "매우 쉬움", "src\\main\\resources\\static\\mountain_images\\mt_96"),
        		new Mountain_recommend("팔영산", "전라남도",	608, "매우 쉬움", "src\\main\\resources\\static\\mountain_images\\mt_97"),
        		new Mountain_recommend("한라산", "제주도",	1950, "보통", "src\\main\\resources\\static\\mountain_images\\mt_98")
 
        );

        mountainRepository.saveAll(mountains);
    }
}
