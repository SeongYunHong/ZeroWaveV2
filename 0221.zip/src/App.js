import React, { useState, useEffect } from 'react';
import { BrowserRouter, Routes, Route, Link, useLocation, useNavigate } from 'react-router-dom';
import Mainpage from './Mainpage/Mainpage';
import Mountain from './Mountain/Mountain';

import Notice from './Notice/Notice';
import NoticeDetail from './Notice/NoticeDetail';

import Admin_Notice from './Admin_Notice/Admin_Notice';
import Admin_Notice_New from './Admin_Notice/Admin_Notice_New';
import Admin_Notice_Detail from './Admin_Notice/Admin_Notice_Detail';
import Admin_Notice_Update from './Admin_Notice/Admin_Notice_Update';

import Reception from './Reception/Reception';

import Mypage from './Mypage/Mypage';
import Signup from './Signup/Signup';

import Admin_Signup from './Signup/Admin_Signup';

import Fire_Signup from './Signup/Fire_Signup';

import Modal from './Modal/Modal';

import 'bootstrap/dist/css/bootstrap.min.css';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faBars, faTimes, faAngleRight } from '@fortawesome/free-solid-svg-icons';
import './style.css';

import logoImage from './static/logo.png';
import userIcon from './static/user_icon.png';

const Navigation = ({ onOpenModal }) => {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const location = useLocation();
  const navigate = useNavigate();

  useEffect(() => {
    const token = localStorage.getItem('token');
    setIsLoggedIn(!!token);
  }, []);

  // 로그인 페이지에서는 네비게이션 바를 표시하지 않음
  // if (location.pathname === '/login') {
  //   return null;
  // }

  const handleLogout = (event) => {
    event.preventDefault();
    localStorage.removeItem('token');
    setIsLoggedIn(false);
    navigate('/');
  };

  return (
    <>
      <header id="header">
        <section className="containerV1">
          <div className="itemBox">
            <div className="menuBox_bg hidden"></div>
            <h1 id="logo">
              <Link to="/" className='logo'>
                <img src={logoImage} alt="로고" />
              </Link>
            </h1>
            {/* 모바일 열기 버튼 */}
            <div className="open_btn visible-sm visible-xs">
              <FontAwesomeIcon className='icon1' icon={faBars} />
            </div>
            <nav id="nav">
              <div className="nav_inner">
                <div className="nav_topBox">
                  <Link to="/" className="nav_logo">모바일로고</Link>
                  {/* 모바일 닫기 버튼 */}
                  <div className="close_btn visible-sm visible-xs">
                    <FontAwesomeIcon className='icon1' icon={faTimes} />
                  </div>
                </div>
                <ul className="outer">
                  <li>
                    <Link to="/mountain" className="">
                      <span>추천 등산로</span>
                      <FontAwesomeIcon className='icon1' icon={faAngleRight} />
                    </Link>
                  </li>                  
                  <li>
                    <Link to="/reception" className="">
                      <span>접수현황</span>
                      <FontAwesomeIcon className='icon1' icon={faAngleRight} />
                    </Link>
                  </li>
                  {isLoggedIn ? (
                    <li>
                      <div className='nav-item user-icon'>
                        <img src={userIcon} className='user_icon' alt="사용자" />
                        <div className="user-menu-dropdown">
                          <ul className="inner">
                            <li><button onClick={onOpenModal}>회원 정보 수정</button></li>
                            <li><button onClick={handleLogout}>로그아웃</button></li>
                          </ul>
                        </div>
                      </div>
                    </li>
                  ) : (
                    <li>
                      <Link to="/login" className='nav-link'>로그인 및 회원가입</Link>
                    </li>
                  )}
                </ul>
              </div>
            </nav>
          </div>
        </section>
      </header>
      <footer>
        COPYRIGHT © 2024 ZEROWAVE ALL RIGHTS RESERVED.
      </footer>
    </>
  );
};

function App() {
  const [showModal, setShowModal] = useState(false);

  const handleOpenModal = () => setShowModal(true);
  const handleCloseModal = () => setShowModal(false);




  return (
    <BrowserRouter>
      <Navigation onOpenModal={handleOpenModal} />
      {
        showModal && (
          <Modal onClose={handleCloseModal}>
            <Mypage onCloseModal={handleCloseModal} />
          </Modal>
        )
      }
      <div className="App">
        <Routes>
          <Route path="/" element={<Mainpage />} />
          <Route path="/mountain" element={<Mountain />} />
          <Route path="/notice" element={<Notice />} />
          <Route path="/notice/:noticeId" element={<NoticeDetail />} />
          <Route path="/admin/notice" element={<Admin_Notice />} />
          <Route path="/admin/notice/new" element={<Admin_Notice_New />} />
          <Route path="/admin/notice/:noticeId" element={<Admin_Notice_Detail />} />
          <Route path="/admin/notice/update/:noticeId" element={<Admin_Notice_Update />} />
          <Route path="/reception" element={<Reception />} />
          <Route path="/login" element={<Signup />} />
          <Route path="/admin/login" element={<Admin_Signup />} />
          <Route path="/fire/login" element={<Fire_Signup />} />
        </Routes>
      </div>
    </BrowserRouter>
  );
}

export default App;