import React from "react";
import { useState, useEffect, useRef } from "react";
import { Link, useNavigate } from 'react-router-dom';
import axios from "axios";
import plusbutton from "../static/plus_button.png"

import '../style.css'
/* global kakao */
const loadKakaoMapsScript = (appKey) => {
    const script = document.createElement('script');
    script.async = true;
    script.src = `//dapi.kakao.com/v2/maps/sdk.js?appkey=${appKey}&autoload=false`;
    document.head.appendChild(script);
    return script;
};

function Mainpage() {
    const [counts, setCounts] = useState({ 진화중: 0, 진화완료: 0, 산불외종료: 0, });
    const [notices, setNotices] = useState([]);
    const navigate = useNavigate();
    const mapRef = useRef(null); // 지도를 담을 ref 생성
    const map = useRef(null); // 지도 인스턴스를 담을 ref

    // 사용자의 현재 위치를 가져와 지도 중심을 이동시키고 마커를 생성하는 함수
    const getCurrentLocation = () => {
        if (navigator.geolocation) {
            navigator.geolocation.getCurrentPosition((position) => {
                const lat = position.coords.latitude,
                    lon = position.coords.longitude;
                const locPosition = new kakao.maps.LatLng(lat, lon);

                if (map.current) {
                    map.current.panTo(locPosition);
                    new kakao.maps.Marker({
                        map: map.current,
                        position: locPosition
                    });
                }
            }, () => {
                alert("위치 정보를 가져올 수 없습니다.");
            });
        } else {
            alert("이 브라우저에서는 위치 정보를 지원하지 않습니다.");
        }
    };

    useEffect(() => {
        const appKey = 'f6bac856fcd6429389ace76f13ffaf23'; // 여기에 실제 앱 키를 입력하세요
        const script = loadKakaoMapsScript(appKey);

        script.onload = () => {
            kakao.maps.load(() => {
                var mapContainer = mapRef.current, // 지도를 표시할 div
                    mapOption = {
                        center: new kakao.maps.LatLng(37.56646, 126.98121), // 지도의 중심좌표
                        level: 3, // 지도의 확대 레벨
                        mapTypeId: kakao.maps.MapTypeId.ROADMAP // 지도종류
                    };

                // 지도를 생성하고 map ref에 할당
                map.current = new kakao.maps.Map(mapContainer, mapOption);
            });
        };

        return () => {
            document.head.removeChild(script);
        };
    }, []);


    // 산불 현황
    useEffect(() => {
        const fetchData = async () => {
            try {
                // 상태 코드에 따라 요청
                const responses = await Promise.all([
                    axios.get('http://localhost:8081/api/fireReception/count/0'),
                    axios.get('http://localhost:8081/api/fireReception/count/1'),
                    axios.get('http://localhost:8081/api/fireReception/count/2'),
                ]);
                console.log(responses[1].data);
                // 응답에서 데이터 설정
                setCounts({
                    진화중: responses[0].data,
                    진화완료: responses[1].data,
                    산불외종료: responses[2].data,
                });
            } catch (error) {
                console.error("Error fetching data:", error);
            }
        };

        fetchData();
    }, []);

    // 공지사항
    useEffect(() => {
        const fetchNotices = async () => {
            try {
                const response = await axios.get('http://localhost:8081/api/notice');
                setNotices(response.data);
            } catch (error) {
                console.error('공지사항 데이터를 불러오는 데 실패했습니다.', error);
            }
        };

        fetchNotices();
    }, []);

    const gotoNotice = () => {
        navigate('/notice');
    }



    return (
        <main className='index'>
            <div className='bg'></div>
            <div className='containerV1'>
                <article className='itemBox'>
                    <section className='map_wrap'>
                        <div>
                            <div ref={mapRef} style={{ width: '750px', height: '350px' }}></div>
                            <button onClick={getCurrentLocation} type="button" className="btn btn-lg btn-primary">내 위치 가져오기</button>
                        </div>
                    </section>
                    <section className='right_contents'>
                        <ul className='fire_state_box'>
                            <li>
                                <p className='text1'>진화 중</p>
                                {counts.진화중}
                            </li>
                            <li>
                                <p className='text1'>진화 완료</p>
                                {counts.진화완료}
                            </li>
                            <li>
                                <p className='text1'>산불 외 종료</p>
                                {counts.산불외종료}
                            </li>
                        </ul>
                        <div className='gi_shang_chung'>
                            기상청 관련 <br />
                            Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.
                            Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.
                            Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.
                            Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.
                        </div>
                        <div className='bottom_box'>
                            <div className='notice_box item'>
                                <div className="notice-container">
                                    <div className="notice-header">
                                        <h3>공지사항</h3>
                                        <img src={plusbutton} className='plusbutton' onClick={gotoNotice} alt="공지사항 더보기" />
                                    </div>
                                    <div className="notice-list">
                                        <table className="notice-table">
                                            <thead>
                                                <tr>
                                                    <th>번호</th>
                                                    <th>제목</th>
                                                    <th>작성일</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                {notices.map((notice) => (
                                                    <tr key={notice.num}>
                                                        <td>{notice.num}</td>
                                                        <td>
                                                            <Link to={`/notice/${notice.num}`}>{notice.title}</Link>
                                                        </td>
                                                        <td>{new Date(notice.createDate).toLocaleDateString()}</td>
                                                    </tr>
                                                ))}
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                            <div className='olhae_sanbul_balsaeng item'>
                                올해산불발생 <br />
                                Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.
                                Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.
                                Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.
                                Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.
                                Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.
                            </div>
                        </div>
                    </section>
                </article>
            </div>
        </main>
    )
}
export default Mainpage;