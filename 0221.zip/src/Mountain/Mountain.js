import React, { useState, useEffect } from 'react';
import axios from 'axios';
import './Mountain.css';

function Mountain() {
  const [mountains, setMountains] = useState([]); // 산의 정보를 저장할 상태
  const [open, setOpen] = useState({}); // 각 산의 상세 정보 표시 상태

  // 산 정보 불러오기
  useEffect(() => {
    axios.get('http://localhost:8081/api/mountain')
      .then(response => {
        console.log('Get success:', response);
        setMountains(response.data); // 응답 데이터로 상태 업데이트
      })
      .catch(error => {
        console.error('Get error:', error);
      });
  }, []);

  // 항목의 상태를 토글하는 함수
  const toggleItem = (index) => {
    setOpen(prevState => ({
      ...prevState,
      [index]: !prevState[index]
    }));
  };

  // 리스트 항목과 상세 정보를 렌더링하는 함수
  const renderItem = (item, index) => (
    <div key={index} className="list-item-container">
      <a href="#"
         className="list-group-item list-group-item-action"
         onClick={(e) => { e.preventDefault(); toggleItem(index); }}>
        {item.name} <span className="toggle-icon">{open[index] ? '-' : '+'}</span>
      </a>
      {open[index] && (
        <div className="detail-info">
          {/* 예시로 산의 상세 정보 표시, 실제 데이터 구조에 맞게 조정 필요 */}
          <p>주소: {item.address}</p>
          <p>높이: {item.height}</p>
          <p>소요 시간: {item.time}</p>
        </div>
      )}
    </div>
  );

  return (
    <div className="list-group">
      {mountains.map((mountain, index) => renderItem(mountain, index))}
    </div>
  );
}

export default Mountain;
