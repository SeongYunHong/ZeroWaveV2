import React from 'react';
import { useLocation } from 'react-router-dom';
import './Subtitle.css';

function Subtitle() {
    const location = useLocation(); // 현재 위치 정보를 가져옴

    // 현재 경로에 따라 서브 타이틀 텍스트 결정
    let subtitleText;
    if (location.pathname === '/mountain') {
        subtitleText = '추천 등산로';
    } else if (location.pathname.startsWith('/notice') || location.pathname.startsWith('/admin/notice')) {  
        subtitleText = '공지사항';
    } else if (location.pathname === '/reception') {
        subtitleText = '접수현황';
    } else if (location.pathname.startsWith('/login') || location.pathname.startsWith('/admin/login') || location.pathname.startsWith('/fire/login')){
        subtitleText = '로그인 & 회원가입';    
    } else if (location.pathname.startsWith('/fire/result')){
        subtitleText = '상황 일지'; 
    } else {
        subtitleText = 'fire alert'; // 기본값
    }

    return (
        <>
            <div className="sub_title">
                <div className="contents">
                    <div className="titleBox">
                        <span className="text1">Zero Wave Tech</span>
                        <p className="text2">{subtitleText}</p>
                    </div>
                </div>
                <figure className='bg_img'></figure>
            </div>
        </>
    );
}

export default Subtitle;