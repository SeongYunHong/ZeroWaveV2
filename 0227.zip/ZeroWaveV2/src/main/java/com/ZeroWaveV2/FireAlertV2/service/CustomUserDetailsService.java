//package com.ZeroWaveV2.FireAlertV2.service;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.security.core.userdetails.UserDetailsService;
//import org.springframework.security.core.userdetails.UsernameNotFoundException;
//
//import com.ZeroWaveV2.FireAlertV2.model.Member;
//import com.ZeroWaveV2.FireAlertV2.repository.UserRepository;
//
//public class CustomUserDetailsService implements UserDetailsService {
//
//    @Autowired
//    private UserRepository userRepository;
//
//    @Override
//    public CustomUserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
//        Member user = userRepository.findByUsername(username)
//            .orElseThrow(() -> new UsernameNotFoundException("User not found with username: " + username));
//
//        CustomUserDetails customUserDetails = new CustomUserDetails();
//        customUserDetails.setUsername(user.getUserName());
//        customUserDetails.setPassword(user.getPassword());
//        customUserDetails.setHp(user.getHp()); // 전화번호 설정
//
//        return customUserDetails;
//    }
//}
