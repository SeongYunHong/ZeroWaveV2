package com.ZeroWaveV2.FireAlertV2.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ZeroWaveV2.FireAlertV2.dto.FireReceptionDto;
import com.ZeroWaveV2.FireAlertV2.model.FireReception;
import com.ZeroWaveV2.FireAlertV2.repository.FireReceptionRepository;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.IOException;
import java.nio.file.*;
import java.text.SimpleDateFormat;
import java.util.Base64;
import java.util.Date;

@Service
public class KafkaConsumerService {

    @Autowired
    private FireReceptionRepository fireReceptionRepository;

    @Autowired
    private ObjectMapper objectMapper;

    @Value("${spring.kafka.consumer.group-id}")
    private String groupId;

    @Value("${firealert.image.storage}")
    private String imageStoragePath;

    @KafkaListener(topics = "firealert_topic", groupId = "${spring.kafka.consumer.group-id}")
    @Transactional
    public void consumeMessage(String message) {
        try {
            FireReceptionDto fireReceptionDto = parseMessage(message);

            byte[] decodedImage = Base64.getDecoder().decode(fireReceptionDto.getImgurl());
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMddHHmmss");
            String fileName = dateFormat.format(new Date()) + ".jpg";
            Path directoryPath = Paths.get(imageStoragePath);
            if (!Files.exists(directoryPath)) {
                Files.createDirectories(directoryPath); // 디렉터리가 없으면 생성
            }
            Path imagePath = directoryPath.resolve(fileName);

            Files.write(imagePath, decodedImage);

            FireReception fireReception = new FireReception();
            fireReception.setImgurl(imagePath.toString());
            fireReception.setAdate(fireReceptionDto.getAdate());
            // 추가 필드 설정 로직 구현

            fireReceptionRepository.save(fireReception);

            System.out.println("메시지 수신 및 처리 성공: " + message);
        } catch (IOException e) {
            e.printStackTrace();
            System.err.println("이미지 저장 중 오류 발생: " + e.getMessage());
        } catch (Exception e) {
            e.printStackTrace();
            System.err.println("메시지 파싱 또는 데이터베이스 저장 중 오류 발생: " + e.getMessage());
        }
    }

    private FireReceptionDto parseMessage(String message) {
        try {
            return objectMapper.readValue(message, FireReceptionDto.class);
        } catch (IOException e) {
            throw new RuntimeException("메시지 파싱 실패", e);
        }
    }
}
