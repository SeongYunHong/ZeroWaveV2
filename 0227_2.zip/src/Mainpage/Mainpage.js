/* global kakao */
import React from "react";
import { useState, useEffect, useRef } from "react";
import { Link, useNavigate } from 'react-router-dom';
import axios from "axios";

import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faChevronRight } from '@fortawesome/free-solid-svg-icons';

import '../style.css'

const loadKakaoMapsScript = (appKey) => {
    const script = document.createElement('script');
    script.async = true;
    script.src = `//dapi.kakao.com/v2/maps/sdk.js?appkey=${appKey}&autoload=false`;
    document.head.appendChild(script);
    return script;
};

function Mainpage() {
    const [counts, setCounts] = useState({ 진화중: 0, 진화완료: 0, 산불외종료: 0, });
    const [notices, setNotices] = useState([]);
    const navigate = useNavigate();
    const mapRef = useRef(null); // 지도를 담을 ref 생성
    const [map, setMap] = useState(null);
    const [weatherData, setWeatherData] = useState(null);


    // 좌표 변환 상수
    const RE = 6371.00877; // 지구 반지름 (km)
    const GRID = 5.0; // 격자 간격 (km)
    const SLAT1 = 30.0; // 투영 위도 1 (도)
    const SLAT2 = 60.0; // 투영 위도 2 (도)
    const OLON = 126.0; // 기준 경도 (도)
    const OLAT = 38.0; // 기준 위도 (도)
    const XO = 43; // 원점 X 좌표 (GRID)
    const YO = 136; // 원점 Y 좌표 (GRID)

    // LCC DFS 좌표 변환 함수
    function dfs_xy_conv(code, v1, v2) {
        const DEGRAD = Math.PI / 180.0;
        const RADDEG = 180.0 / Math.PI;

        const re = RE / GRID;
        const slat1 = SLAT1 * DEGRAD;
        const slat2 = SLAT2 * DEGRAD;
        const olon = OLON * DEGRAD;
        const olat = OLAT * DEGRAD;

        let sn = Math.tan(Math.PI * 0.25 + slat2 * 0.5) / Math.tan(Math.PI * 0.25 + slat1 * 0.5);
        sn = Math.log(Math.cos(slat1) / Math.cos(slat2)) / Math.log(sn);
        let sf = Math.tan(Math.PI * 0.25 + slat1 * 0.5);
        sf = Math.pow(sf, sn) * Math.cos(slat1) / sn;
        let ro = Math.tan(Math.PI * 0.25 + olat * 0.5);
        ro = re * sf / Math.pow(ro, sn);
        let rs = {};
        if (code === "toXY") {
            rs['lat'] = v1;
            rs['lng'] = v2;
            let ra = Math.tan(Math.PI * 0.25 + (v1) * DEGRAD * 0.5);
            ra = re * sf / Math.pow(ra, sn);
            let theta = v2 * DEGRAD - olon;
            if (theta > Math.PI) theta -= 2.0 * Math.PI;
            if (theta < -Math.PI) theta += 2.0 * Math.PI;
            theta *= sn;
            rs['x'] = Math.floor(ra * Math.sin(theta) + XO + 0.5);
            rs['y'] = Math.floor(ro - ra * Math.cos(theta) + YO + 0.5);
        }
        return rs;
    }

    function calculateWindDirection(u, v) {
        // UUU와 VVV 값을 사용하여 풍향 계산
        const angle = Math.atan2(u, v) * (180 / Math.PI);
        const degrees = (angle < 0 ? angle + 360 : angle);

        if (degrees > 315 || degrees <= 45) {
            return 'N-NE';
        } else if (degrees > 45 && degrees <= 90) {
            return 'NE-E';
        } else if (degrees > 90 && degrees <= 135) {
            return 'E-SE';
        } else if (degrees > 135 && degrees <= 180) {
            return 'SE-S';
        } else if (degrees > 180 && degrees <= 225) {
            return 'S-SW';
        } else if (degrees > 225 && degrees <= 270) {
            return 'SW-W';
        } else if (degrees > 270 && degrees <= 315) {
            return 'W-NW';
        } else {
            return 'NW-N';
        }
    }

    // 기상청 API를 사용하여 날씨 데이터 가져오기
    const fetchWeatherData = (gridX, gridY) => {
        // 현재 시간 기준으로 baseDate 및 baseTime 설정
        const now = new Date();
        let baseDate;
        let baseTime;

        if (now.getMinutes() >= 40) {
            // 40분 이후이면 현재 시간을 사용
            baseDate = `${now.getFullYear()}${String(now.getMonth() + 1).padStart(2, '0')}${String(now.getDate()).padStart(2, '0')}`;
            baseTime = `${String(now.getHours()).padStart(2, '0')}00`;
        } else {
            // 40분 이전이면 한 시간 전 데이터를 사용
            now.setHours(now.getHours() - 1);
            baseDate = `${now.getFullYear()}${String(now.getMonth() + 1).padStart(2, '0')}${String(now.getDate()).padStart(2, '0')}`;
            baseTime = `${String(now.getHours()).padStart(2, '0')}00`;
        }

        const encodedServiceKey = 'BHpQTexrH%2FOEjVR2zDPhMQ3v%2FZkfRBCR5LD8YR6iUBG8td9NeFggtx2yNVB6w4ttERGo7dTzRq5OTkCnC40zfw%3D%3D'; // 여기에 실제 인코딩된 서비스 키를 사용하세요.
        const url = `http://apis.data.go.kr/1360000/VilageFcstInfoService_2.0/getUltraSrtNcst`;
        const queryParams = `?serviceKey=${encodedServiceKey}&pageNo=1&numOfRows=10&dataType=JSON&base_date=${baseDate}&base_time=${baseTime}&nx=${gridX}&ny=${gridY}`;

        fetch(url + queryParams)
            .then(response => response.json())
            .then(data => {
                console.log(data); // API 응답 로깅
                if (data.response.header.resultCode === "00" && data.response.body.items.item.length > 0) {
                    const { T1H, REH, RN1, UUU, VVV, WSD } = data.response.body.items.item.reduce((acc, current) => {
                        acc[current.category] = current.obsrValue;
                        return acc;
                    }, {});
                    setWeatherData({ T1H, REH, RN1, UUU, VVV, WSD });
                } else {
                    console.error('날씨 데이터를 가져오는 데 실패했습니다.', data.response.header.resultMsg);
                }
            })
            .catch(error => {
                console.error('날씨 데이터를 가져오는 중 오류:', error);
            });
    };



    // 현재 위치 가져오기 및 지도에 마커 표시
    const getCurrentLocation = () => {
        if (navigator.geolocation) {
            navigator.geolocation.getCurrentPosition((position) => {
                const lat = position.coords.latitude;
                const lon = position.coords.longitude;
                const grid = dfs_xy_conv("toXY", lat, lon);

                // 지도의 중심을 현재 위치로 이동
                const moveLatLon = new kakao.maps.LatLng(lat, lon);
                if (map) {
                    map.setCenter(moveLatLon);

                    // 현재 위치에 새로운 마커 생성
                    const marker = new kakao.maps.Marker({
                        position: moveLatLon
                    });
                    marker.setMap(map);
                }

                // 날씨 데이터 가져오기
                fetchWeatherData(grid.x, grid.y);
            }, () => {
                alert('위치 정보를 가져올 수 없습니다.');
            });
        } else {
            alert('이 브라우저에서는 Geolocation이 지원되지 않습니다.');
        }
    };

    // 카카오 맵 초기화
    useEffect(() => {
        const appKey = 'f6bac856fcd6429389ace76f13ffaf23'; // 실제 카카오 앱 키로 대체해야 합니다.
        const script = document.createElement('script');
        script.async = true;
        script.src = `//dapi.kakao.com/v2/maps/sdk.js?appkey=${appKey}&autoload=false`;
        document.head.appendChild(script);

        script.onload = () => {
            kakao.maps.load(() => {
                const mapContainer = mapRef.current; // 지도를 표시할 div
                const mapOption = {
                    center: new kakao.maps.LatLng(33.450701, 126.570667), // 지도의 중심좌표
                    level: 3 // 지도의 확대 레벨
                };

                // 지도 생성 및 map 상태 업데이트
                const kakaoMap = new kakao.maps.Map(mapContainer, mapOption);
                setMap(kakaoMap);
            });
        };

        return () => {
            document.head.removeChild(script);
        };
    }, []);


    // 산불 현황
    useEffect(() => {
        const fetchData = async () => {
            try {
                // 상태 코드에 따라 요청
                const responses = await Promise.all([
                    axios.get('http://localhost:8081/api/fireReception/count/0'),
                    axios.get('http://localhost:8081/api/fireReception/count/1'),
                    axios.get('http://localhost:8081/api/fireReception/count/2'),
                ]);
                // 응답에서 데이터 설정
                setCounts({
                    진화중: responses[0].data,
                    진화완료: responses[1].data,
                    산불외종료: responses[2].data,
                });
            } catch (error) {
                console.error("Error fetching data:", error);
            }
        };

        fetchData();
    }, []);

    // 공지사항
    useEffect(() => {
        const fetchNotices = async () => {
            try {
                const response = await axios.get('http://localhost:8081/api/notice');
                setNotices(response.data);
            } catch (error) {
                console.error('공지사항 데이터를 불러오는 데 실패했습니다.', error);
            }
        };

        fetchNotices();
    }, []);

    const gotoNotice = () => {
        navigate('/notice');
    }



    return (
        <main className='index'>
            <div className='bg'></div>
            <div className='containerV1'>
                <article className='itemBox'>
                    <section className='map_wrap'>
                        <div>
                            <div ref={mapRef} style={{ width: '750px', height: '350px' }}></div>
                            <button onClick={getCurrentLocation} type="button" className="btn btn-lg btn-primary">내 위치 가져오기</button>
                        </div>
                    </section>
                    <section className='right_contents'>
                        <ul className='fire_state_box'>
                            <li>
                                <p className='text1'>진화 중</p>
                                {counts.진화중}
                            </li>
                            <li>
                                <p className='text1'>진화 완료</p>
                                {counts.진화완료}
                            </li>
                            <li>
                                <p className='text1'>산불 외 종료</p>
                                {counts.산불외종료}
                            </li>
                        </ul>
                        <div className='gi_shang_chung'>
                            {weatherData && (
                                <div>
                                    <p>기온: {weatherData.T1H}°C</p>
                                    <p>습도: {weatherData.REH}%</p>
                                    <p>강수량: {weatherData.RN1}mm</p>
                                    <p>풍향: {calculateWindDirection(weatherData.UUU, weatherData.VVV)}</p>
                                    <p>풍속: {weatherData.WSD}m/s</p>
                                </div>
                            )}
                        </div>
                        <div className='bottom_box'>
                            <div className='notice_box item'>
                                <div className="notice-container">
                                    <div className="notice-header">
                                        <h3>공지사항</h3>
                                        <FontAwesomeIcon icon={faChevronRight} onClick={gotoNotice} />
                                    </div>
                                    <div className="notice-list">
                                        <table className="notice-table">
                                            <thead>
                                                <tr>
                                                    <th>번호</th>
                                                    <th>제목</th>
                                                    <th>작성일</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                {notices.map((notice) => (
                                                    <tr key={notice.num}>
                                                        <td>{notice.num}</td>
                                                        <td>
                                                            <Link to={`/notice/${notice.num}`}>{notice.title}</Link>
                                                        </td>
                                                        <td>{new Date(notice.createDate).toLocaleDateString()}</td>
                                                    </tr>
                                                ))}
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                            <div className='olhae_sanbul_balsaeng item'>
                                올해산불발생 <br />
                                Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.
                                Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.
                                Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.
                                Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.
                                Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.
                            </div>
                        </div>
                    </section>
                </article>
            </div>
        </main >
    )
}
export default Mainpage;