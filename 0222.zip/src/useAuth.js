import { useState, useEffect } from 'react';
import axios from 'axios';

export const useAuth = () => {
  const [userRole, setUserRole] = useState(null);

  useEffect(() => {
    const fetchUserRole = async () => {
      const token = localStorage.getItem('token');
      if (!token) {
        setUserRole(null);
        return;
      }

      try {
        const response = await axios.get('http://localhost:8081/api/auth/role', {
          headers: {
            'Authorization': `Bearer ${token}`
          }
        });

        // 배열의 첫 번째 역할을 상태로 설정합니다.
        const fetchedRole = response.data.roles;
        console.log(fetchedRole);
        setUserRole(fetchedRole);
        console.log(userRole);
      } catch (error) {
        console.error('Role fetching failed', error);
        setUserRole(null);
      }
    };

    fetchUserRole();
  }, []);
  console.log(userRole);

  return { userRole };
};
