package com.ZeroWaveV2.FireAlertV2.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ZeroWaveV2.FireAlertV2.dto.NoticeDto;
import com.ZeroWaveV2.FireAlertV2.model.Notice;
import com.ZeroWaveV2.FireAlertV2.service.NoticeService;

@RestController
@RequestMapping("/api/notice")
public class NoticeController {

    @Autowired
    private NoticeService noticeService;
    
    @PostMapping
    public ResponseEntity<NoticeDto> createNotice(@RequestBody NoticeDto noticeDto) {
        NoticeDto savedNoticeDto = noticeService.createNotice(noticeDto);
        return new ResponseEntity<>(savedNoticeDto, HttpStatus.CREATED);
    }
    
    @GetMapping
    public ResponseEntity<List<NoticeDto>> getAllNotices() {
        List<NoticeDto> notices = noticeService.findNoticeSummary();
        return ResponseEntity.ok(notices);
    }
    
    // 번호로 공지사항 읽기
    @GetMapping("/{num}")
    public ResponseEntity<NoticeDto> getNoticeByNum(@PathVariable int num) {
        NoticeDto noticeDto = noticeService.getNoticeByNum(num);
        if (noticeDto != null) {
            return ResponseEntity.ok(noticeDto);
        } else {
            return ResponseEntity.notFound().build();
        }
    }
    
    // 공지사항 수정
    @PutMapping("/{num}")
    public ResponseEntity<NoticeDto> updateNotice(@PathVariable int num, @RequestBody NoticeDto noticeDto) {
        NoticeDto updatedNotice = noticeService.updateNotice(num, noticeDto);
        return ResponseEntity.ok(updatedNotice);
    }

    // 공지사항 삭제
    @DeleteMapping("/{num}")
    public ResponseEntity<Void> deleteNotice(@PathVariable int num) {
        noticeService.deleteNotice(num);
        return ResponseEntity.ok().build(); // 성공적으로 삭제되었음을 나타냅니다.
    }
    
    // 조회 수 증가
    @GetMapping("/increaseHit/{num}")
    public ResponseEntity<Void> increaseHit(@PathVariable int num) {
        noticeService.increaseNoticeHit(num);
        return ResponseEntity.ok().build();
    }
    

}
