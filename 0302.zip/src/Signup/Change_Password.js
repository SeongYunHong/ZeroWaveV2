import React, { useState } from 'react';
import axios from 'axios';

function Change_Password() {
  const [hp, setHp] = useState('');
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [message, setMessage] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault(); // 폼 제출 시 페이지 새로고침 방지

    try {
      const response = await axios.put('http://localhost:8081/api/find-password', {
        hp,
        username,
        password
      });
      setMessage(response.data);
      // 비밀번호 변경 성공 후 추가 동작, 예를 들어 로그인 페이지로 리다이렉트
    } catch (error) {
      if (error.response) {
        // 서버에서 제공하는 응답 메시지가 있는 경우
        setMessage(error.response.data);
      } else {
        setMessage('비밀번호 변경 요청 중 오류가 발생했습니다.');
      }
    }
  };

  return (
    <div>
      <h2>비밀번호 변경</h2>
      <form onSubmit={handleSubmit}>
        <div>
          <label>연락처: </label>
          <input type="text" value={hp} onChange={(e) => setHp(e.target.value)} />
        </div>
        <div>
          <label>사용자 이름: </label>
          <input type="text" value={username} onChange={(e) => setUsername(e.target.value)} />
        </div>
        <div>
          <label>새 비밀번호: </label>
          <input type="password" value={password} onChange={(e) => setPassword(e.target.value)} />
        </div>
        <button type="submit">비밀번호 변경</button>
      </form>
      {message && <p>{message}</p>}
    </div>
  );
}

export default Change_Password;
