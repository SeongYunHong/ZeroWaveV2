package com.ZeroWaveV2.FireAlertV2.dto;

import jakarta.validation.constraints.NotBlank;
import lombok.Getter;
import lombok.Setter;

import com.ZeroWaveV2.FireAlertV2.constants.ErrorMessages;

@Getter
@Setter
public class FireStationDto {
	@NotBlank(message = ErrorMessages.FS_REQUIRED)
    private String fs;

    @NotBlank(message = ErrorMessages.PASSWORD_REQUIRED)
    private String password;

    public FireStationDto(String fs, String password) {
        this.fs = fs;
        this.password = password;
    }
}



