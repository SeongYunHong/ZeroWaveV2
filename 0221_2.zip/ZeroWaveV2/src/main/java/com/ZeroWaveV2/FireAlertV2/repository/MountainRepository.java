package com.ZeroWaveV2.FireAlertV2.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.ZeroWaveV2.FireAlertV2.model.Mountain_recommend;

@Repository
public interface MountainRepository extends JpaRepository<Mountain_recommend, String> {
	@Query("SELECT DISTINCT m.address FROM Mountain m")
	List<String> findDistinctAddress();
	
	@Query("SELECT DISTINCT m.season FROM Mountain m")
	List<String> findDistinctSeason();

	@Query("SELECT DISTINCT m.mttime FROM Mountain m")
	List<String> findDistinctMtTime();
	
	@Query("SELECT m FROM Mountain m WHERE m.height >= :minHeight AND m.height <= :maxHeight")
    List<Mountain_recommend> findByHeightRange(@Param("minHeight") int minHeight, @Param("maxHeight") int maxHeight);
}
