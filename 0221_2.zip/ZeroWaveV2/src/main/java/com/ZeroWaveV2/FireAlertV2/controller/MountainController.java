package com.ZeroWaveV2.FireAlertV2.controller;

import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.ZeroWaveV2.FireAlertV2.dto.MountainDto;
import com.ZeroWaveV2.FireAlertV2.service.MountainService;

@RestController
@RequestMapping("/api/mountain")
public class MountainController {

    private final MountainService mountainService;

    public MountainController(MountainService mountainService) {
        this.mountainService = mountainService;
    }

    @GetMapping
    public List<MountainDto> getAllMountains() {
        return mountainService.findAllMountains();
    }
    
    @GetMapping("/filtered")
    public List<MountainDto> getMountainsByFilters(
            @RequestParam(required = false) String address,
            @RequestParam(required = false) String season,
            @RequestParam(required = false) String mttime,
            @RequestParam(required = false) Integer minHeight,
            @RequestParam(required = false) Integer maxHeight) {
        return mountainService.findByFilters(address, season, mttime, minHeight, maxHeight);
    }
}
