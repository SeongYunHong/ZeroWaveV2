import React, { useState } from 'react';
import axios from 'axios';

function Result_Detail() {
    const [result, setResult] = useState({
        dtime: '',
        cdate: '',
        wtime: '',
        ff: 0,
        ftruck: 0,
        hc: 0,
        fw: 0,
        losses: 0,
        lmoney: 0,
        darea: 0,
    });

    const handleChange = (e) => {
        setResult({ ...result, [e.target.name]: e.target.value });
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            const response = await axios.post('http://localhost:8081/api/result', result);
            console.log(response.data);
            alert('제출되었습니다.');
        } catch (error) {
            console.error('Error posting result', error);
        }
    };

    return (
        <form onSubmit={handleSubmit}>
            {/* <div><label>출동 시각: <input name="dtime" type="datetime-local" value={result.dtime} onChange={handleChange} /></label></div>
            <div><label>종료 시간: <input name="cdate" type="datetime-local" value={result.cdate} onChange={handleChange} /></label></div>
            <div><label>걸린 시간: <input name="wtime" type="time" step="1" value={result.wtime} onChange={handleChange} /></label></div> */}
            <div><label>출동 인원: <input name="ff" type="number" value={result.ff} onChange={handleChange} /></label></div>
            <div><label>출동 소방차: <input name="ftruck" type="number" value={result.ftruck} onChange={handleChange} /></label></div>
            <div><label>출동 헬기: <input name="hc" type="number" value={result.hc} onChange={handleChange} /></label></div>
            <div><label>소화수: <input name="fw" type="number" value={result.fw} onChange={handleChange} /></label></div>
            <div><label>사상자: <input name="losses" type="number" value={result.losses} onChange={handleChange} /></label></div>
            <div><label>피해 금액: <input name="lmoney" type="number" value={result.lmoney} onChange={handleChange} /></label></div>
            <div><label>피해 면적: <input name="darea" type="number" value={result.darea} onChange={handleChange} /></label></div>
            <button type="submit">Submit</button>
        </form>
    );
}

export default Result_Detail;