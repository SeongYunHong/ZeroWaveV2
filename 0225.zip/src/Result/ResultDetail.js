import React from 'react';
import { useState, useEffect } from "react";
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import './ResultDetail.css';

function ResultDetail() {
    const [resultData, setResultData] = useState({
        dispatch: '',
        title: '',
        dtime: '',
        cdate: '',
        wtime: '',
        ff: 0,
        ftruck: 0,
        hc: 0,
        fw: 0,
        losses: 0,
        lmoney: 0,
        darea: 0,
    })
    const navigate = useNavigate;

    useEffect(() => {
        const fetchUserRole = async () => {
            const token = localStorage.getItem('token');
            if (!token) {
                alert('소방팀만 접근할 수 있는 페이지입니다.');
                navigate('/');
                return;
            }

            try {
                const response = await axios.get('http://localhost:8081/api/auth/role', {
                    headers: {
                        'Authorization': `Bearer ${token}`
                    }
                });
                // 소방팀인지 확인
                if (!response.data.roles.includes('ROLE_ADMIN', 'ROLE_FIRE')) {
                    alert('소방팀만 접근할 수 있는 페이지입니다.');
                    navigate('/');
                    return;
                }
            } catch (error) {
                console.error('Role fetching failed', error);
                navigate('/');
            }
        };

        fetchUserRole();
    }, [navigate]);

    // 폼 필드 변경 핸들러
    const handleInputChange = (e) => {
        const { name, value } = e.target;
        setResultData({ ...resultData, [name]: value });
    };

    // 폼 제출 핸들러
    const handleSubmit = async (event) => {
        event.preventDefault();
        try {
            const response = await axios.post('http://localhost:8081/api/result', resultData);
            console.log(response.data);
            // 성공적으로 제출 후, 필요한 액션 수행 (예: 폼 초기화, 알림 메시지 표시 등)
        } catch (error) {
            console.error('Error submitting result:', error);
            // 에러 처리 (예: 사용자에게 에러 메시지 표시)
        }
    };

    return (
        <div className="Result" >
            <div className="Card">
                <form onSubmit={handleSubmit}>
                    <label>
                        Dispatch:
                        <input type="number" name="dispatch" value={resultData.dispatch} onChange={handleInputChange} />
                    </label>
                    <label>
                        Title:
                        <input type="text" name="title" value={resultData.title} onChange={handleInputChange} />
                    </label>
                    {/* 다른 필드들에 대한 입력 요소 추가 */}
                    {/* 예: */}
                    <label>
                        Date and Time:
                        <input type="datetime-local" name="dtime" value={resultData.dtime} onChange={handleInputChange} />
                    </label>
                    {/* 나머지 필드에 대한 라벨과 입력 요소 추가 */}
                    <button type="submit">Submit</button>
                </form>
            </div>
        </div >
    );
}
export default ResultDetail;