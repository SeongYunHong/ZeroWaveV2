// Reception.js
import React, { useEffect, useState } from 'react';
import { Client } from '@stomp/stompjs';
import SockJS from 'sockjs-client';

const Reception = () => {
  const [messages, setMessages] = useState([]);

  useEffect(() => {
    const socket = new SockJS('http://localhost:8081/kafka'); // 스프링부트 서버의 WebSocket 엔드포인트 URL
    const client = new Client({
      webSocketFactory: () => socket,
      onConnect: () => {
        console.log('Connected to the WebSocket server');
        client.subscribe('/topic/messages', message => {
          console.log('Received message:', message.body);
          try {
            const newMessage = JSON.parse(message.body);
            setMessages(prevMessages => [...prevMessages, newMessage]);
          } catch (error) {
            console.error('Error parsing message:', error);
          }
        });
      },
      onDisconnect: () => {
        console.log('Disconnected from the WebSocket server');
      },
      // 연결 에러 핸들링
      onStompError: (frame) => {
        console.error('Broker reported error: ' + frame.headers['message']);
        console.error('Additional details: ' + frame.body);
      },
    });

    client.activate();

    return () => {
      client.deactivate();
    };
  }, []);

  return (
    <div>
      <h2>Received Messages</h2>
      <ul>
        {messages.map((msg, index) => (
          <li key={index}>{JSON.stringify(msg)}</li>
        ))}
      </ul>
    </div>
  );
};

export default Reception;
