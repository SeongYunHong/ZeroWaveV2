import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';

const Admin_Notice_New = () => {
    const [title, setTitle] = useState('');
    const [post, setPost] = useState('');
    const [file, setFile] = useState(null); // 이미지 파일 상태
    const navigate = useNavigate();

    useEffect(() => {
        const fetchUserRole = async () => {
          const token = localStorage.getItem('token');
          if (!token) {
            alert('관리자만 접근할 수 있는 페이지입니다.');
            navigate('/');
            return;
          }
    
          try {
            const response = await axios.get('http://localhost:8081/api/auth/role', {
              headers: {
                'Authorization': `Bearer ${token}`
              }
            });
            // 관리자인지 확인
            if (!response.data.roles.includes('ROLE_ADMIN')) {
              alert('관리자만 접근할 수 있는 페이지입니다.');
              navigate('/');
              return;
            }
          } catch (error) {
            console.error('Role fetching failed', error);
            navigate('/');
          }
        };
    
        fetchUserRole();
      }, [navigate]);

    const handleFileChange = (event) => {
        setFile(event.target.files[0]);
    };

    const handleSubmit = async (event) => {
        event.preventDefault();

        const formData = new FormData();
        formData.append('file', file);

        try {
            // 이미지 업로드
            const uploadRes = await axios.post('http://localhost:8081/api/upload', formData, {
                headers: {
                    'Content-Type': 'multipart/form-data',
                },
            });

            // 공지사항 생성
            const { imgurl } = uploadRes.data;
            await axios.post('http://localhost:8081/api/notice', {
                title,
                post,
                imgurl,
            });

            alert('공지사항이 성공적으로 작성되었습니다.');
            navigate('/admin/notice');
        } catch (error) {
            console.error('공지사항 작성 실패', error);
            alert('공지사항 작성에 실패했습니다.');
        }
    };

    return (
        <form onSubmit={handleSubmit}>
            <label htmlFor="title">제목</label>
            <input id="title" value={title} onChange={(e) => setTitle(e.target.value)} />

            <label htmlFor="post">내용</label>
            <textarea id="post" value={post} onChange={(e) => setPost(e.target.value)} />

            <label htmlFor="file">이미지 첨부</label>
            <input
                type="file"
                accept="image/*"
                onChange={handleFileChange}
            />

            <button type="submit">작성하기</button>
        </form>
    );
}

export default Admin_Notice_New;
