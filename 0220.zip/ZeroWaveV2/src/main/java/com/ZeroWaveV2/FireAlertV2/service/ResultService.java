package com.ZeroWaveV2.FireAlertV2.service;

import com.ZeroWaveV2.FireAlertV2.model.Result;
import com.ZeroWaveV2.FireAlertV2.model.FireReception;
import com.ZeroWaveV2.FireAlertV2.repository.ResultRepository;
import com.ZeroWaveV2.FireAlertV2.repository.FireReceptionRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class ResultService {

    @Autowired
    private ResultRepository resultRepository;
    
    @Autowired
    private FireReceptionRepository fireReceptionRepository;

    @Transactional
    public Result saveResult(Result result) {
        // Result 객체 저장
        Result savedResult = resultRepository.save(result);

        // 관련 FireReception 객체의 progress 상태 업데이트
        FireReception fireReception = savedResult.getFireSituationRoom().getFireReception();
        fireReception.setProgress("완료");
        fireReceptionRepository.save(fireReception);

        return savedResult;
    }
}
