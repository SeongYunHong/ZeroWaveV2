package com.ZeroWaveV2.FireAlertV2.dto;

import com.ZeroWaveV2.FireAlertV2.model.User;
import com.ZeroWaveV2.FireAlertV2.model.FireSituationRoom;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.util.Date;
import java.util.List;

@Data
@NoArgsConstructor
public class FireReceptionDto {
    private int num;
    private User user;
    private String imgurl;
    private Date adate;
    private String gps;
    private String progress;
    private List<FireSituationRoom> fireSituationRoom;
    
    public FireReceptionDto(String imgurl, Date adate, String gps, String process) {
    	this.imgurl = imgurl;
    	this.adate = adate;
    	this.gps = gps;
    	this.progress = process;
    }

    // 모든 필드를 가지는 생성자
    public FireReceptionDto(int num, User user, String imgurl, Date adate, String gps, String progress, List<FireSituationRoom> fireSituationRoom) {
        this.num = num;
        this.user = user;
        this.imgurl = imgurl;
        this.adate = adate;
        this.gps = gps;
        this.progress = progress;
        this.fireSituationRoom = fireSituationRoom;
    }

    // 이미지와 날짜만을 인자로 받는 생성자
    public FireReceptionDto(String imgurl, Date adate) {
        this.imgurl = imgurl;
        this.adate = adate;
    }
}
