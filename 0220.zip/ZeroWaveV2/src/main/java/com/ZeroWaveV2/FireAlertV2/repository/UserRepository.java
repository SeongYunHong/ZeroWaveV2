package com.ZeroWaveV2.FireAlertV2.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.ZeroWaveV2.FireAlertV2.model.Member;

@Repository
public interface UserRepository extends JpaRepository<Member, String> {
    Member findByHp(String hp);
    Member findByUserName(String userName);
    boolean existsByHp(String hp);
}
