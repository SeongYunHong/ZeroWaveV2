package com.ZeroWaveV2.FireAlertV2.repository;

import com.ZeroWaveV2.FireAlertV2.model.Result;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ResultRepository extends JpaRepository<Result, Long> {
    // 추가적인 메소드를 정의할 수 있습니다.
}
