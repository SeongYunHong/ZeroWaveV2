package com.ZeroWaveV2.FireAlertV2.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ZeroWaveV2.FireAlertV2.dto.FireReceptionDto;
import com.ZeroWaveV2.FireAlertV2.service.FireReceptionService;

@RestController
@RequestMapping("/api/fireReception")
public class FireReceptionController {
    
    @Autowired
    private FireReceptionService fireReceptionService;

    @GetMapping
    public ResponseEntity<List<FireReceptionDto>> getFireReceptions(@AuthenticationPrincipal UserDetails currentUser) {
        // UserDetails에서 사용자의 hp를 추출
        String hp = currentUser.getUsername(); // JWT 토큰에 저장된 hp 정보 사용

        // 해당 hp를 기반으로 FireReception 정보 조회
        List<FireReceptionDto> fireReceptions = fireReceptionService.findByHp(hp);
        
        if (fireReceptions.isEmpty()) {
            return ResponseEntity.notFound().build();
        }
        
        return ResponseEntity.ok(fireReceptions);
    }
}
