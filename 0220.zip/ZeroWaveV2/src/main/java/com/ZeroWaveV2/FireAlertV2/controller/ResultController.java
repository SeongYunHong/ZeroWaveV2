package com.ZeroWaveV2.FireAlertV2.controller;

import com.ZeroWaveV2.FireAlertV2.model.Result;
import com.ZeroWaveV2.FireAlertV2.service.ResultService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class ResultController {

    @Autowired
    private ResultService resultService;

    @PostMapping("/results")
    public Result createResult(@RequestBody Result result) {
        return resultService.saveResult(result);
    }
}
