import React, { useState, useEffect } from 'react';
import axios from 'axios';
import './Reception.css';

function Reception() {
  const [receptions, setReceptions] = useState([]);
//   const imageUrl = "http://localhost:8081/firealert_images/test.jpg";
  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await axios.get('http://localhost:8081/api/fireReception', {
            headers: {
                'Authorization': `Bearer ${localStorage.getItem('token')}`
            }
        });
        setReceptions(response.data);
      } catch (error) {
        console.error('데이터를 가져오는데 실패했습니다.', error);
      }
    };

    fetchData();
  }, []);

  // imgurl 변환 함수
    const convertImageUrl = (relativeUrl) => {
        const baseUrl = "http://localhost:8081";
        const imagePath = relativeUrl.split("static")[1].replace(/\\/g, "/");
        return `${baseUrl}${imagePath}`;
    };

    // 날짜 포맷 변환 함수
  const formatDate = (dateString) => {
    return dateString.substring(0, 10);
  };

  return (
    <div className="gallery">
      <div className="gallery-grid">
        {receptions.map((reception, index) => (
          <div className="gallery-item" key={index}>
            <img src={convertImageUrl(reception.imgurl)} alt={`Reception ${index}`} />
            <div className="gallery-item-info">
              <p>날짜: {formatDate(reception.adate)}</p>
              <p>위치: {reception.gps}</p>
              <p>진행 상태: {reception.progress}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

export default Reception;
