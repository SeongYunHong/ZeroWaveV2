import { useState, useEffect } from 'react';
import axios from 'axios';

export const useAuth = () => {
  const [userRole, setUserRole] = useState(null);
  const role = useState(null);
  useEffect(() => {
    const fetchUserRole = async () => {
      const token = localStorage.getItem('token');
      if (!token) {
        setUserRole(null);
        return;
      }

      try {
        const response = await axios.get('http://localhost:8081/api/auth/role', {
          headers: {
            'Authorization': `Bearer ${token}`
          }
        });

        // 배열의 첫 번째 역할을 상태로 설정합니다.
        const fetchedRole = response.data.roles && response.data.roles[0];
        console.log(fetchedRole);
        //setUserRole(fetchedRole);
        role=fetchedRole;
      } catch (error) {
        console.error('Role fetching failed', error);
        setUserRole(null);
      }
    };

    fetchUserRole();
  }, []);
  setUserRole(role);
  console.log(userRole);
  // 상태가 업데이트될 때 로그를 찍기 위한 useEffect
  useEffect(() => {
    console.log(`Current role: ${userRole}`);
  }, [userRole]);

  return userRole;
};
