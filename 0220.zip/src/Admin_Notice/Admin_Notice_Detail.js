import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useParams, useNavigate } from 'react-router-dom'; // useParams 훅 임포트
import { useAuth } from '../useAuth';
import './Admin_Notice_Detail.css'

const Admin_Notice_Detail = () => {
    const [detail, setDetail] = useState(null);
    const { noticeId } = useParams(); // useParams 훅을 사용하여 경로 파라미터에서 noticeId 추출
    const [isHitIncreased, setIsHitIncreased] = useState(false);
    const navigate = useNavigate();
    const userRole = useAuth();

  useEffect(() => {
    if (userRole !== 'ADMIN') {
      alert('관리자만 접근할 수 있는 페이지입니다.');
      navigate(`/`);
      return;
    }
  }, [userRole, navigate]); // 권한 확인 로직에 사용되는 변수들을 의존성 배열에 추가

    useEffect(() => {
        // 세부 정보를 가져오는 함수
        const fetchDetail = async () => {
            try {
                const detailResponse = await axios.get(`http://localhost:8081/api/notice/${noticeId}`);
                setDetail(detailResponse.data);
            } catch (error) {
                console.error('공지사항 세부 정보를 불러오는 데 실패했습니다.', error);
            }
        };
        fetchDetail();
    }, [noticeId]);

    // 조회수를 증가시키는 함수
    const increaseHit = async () => {
        try {
            await axios.get(`http://localhost:8081/api/notice/increaseHit/${noticeId}`);
        } catch (error) {
            console.error('공지사항 조회수 증가 중 오류 발생', error);
        }
    };

    useEffect(() => {
        if (detail && !isHitIncreased) {
            increaseHit();
            setIsHitIncreased(true); // 조회수가 증가되었다는 표시를 상태에 저장합니다.
        }
    }, [detail]);

    if (!detail) {
        return <div className='notice_detail'>Loading...</div>;
    }

    // 날짜 형식을 한국식으로 변경 (예: 2020년 3월 25일)
    const formattedDate = new Date(detail.createDate).toLocaleDateString('ko-KR', {
        year: 'numeric',
        month: 'long',
        day: 'numeric'
    });

    // imgurl 변환 함수
    const convertImageUrl = (relativeUrl) => {
        const baseUrl = "http://localhost:8081";
        const imagePath = relativeUrl.split("static")[1].replace(/\\/g, "/");
        return `${baseUrl}${imagePath}`;
    };

    const gotoNotice = () => {
        navigate('/admin/notice');
    };

    const updateNotice = () => {
        navigate(`/admin/notice/update/${noticeId}`);
    }

    const deleteNotice = async () => {
        const confirmation = window.confirm('게시물을 삭제하시겠습니까?');
        if (!confirmation) {
            return;
        }

        try {
            const response = await axios.delete(`http://localhost:8081/api/notice/${noticeId}`);
            alert('게시물이 성공적으로 삭제되었습니다.');
            navigate('/admin/notice');
        } catch (error) {
            console.error('게시물 삭제 실패', error);
            alert('게시물 삭제 중 문제가 발생했습니다.');
        }

    }

    return (
        <div className='notice_detail'>
            <h1>{detail.title}</h1>
            <div className="notice_info">
                <span>작성일: {formattedDate}</span>
                <span>조회수: {detail.hit}</span>
            </div>
            <div><img src={convertImageUrl(detail.imgurl)} /></div>
            <div dangerouslySetInnerHTML={{ __html: detail.post }} />
            <div className="notice_navigation">
                <button onClick={updateNotice}>수정</button>
                <button onClick={deleteNotice}>삭제</button>
                <button onClick={gotoNotice}>목록으로</button>
            </div>
        </div>
    );
};

export default Admin_Notice_Detail;
