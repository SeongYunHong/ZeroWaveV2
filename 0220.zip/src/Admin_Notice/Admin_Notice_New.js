import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import { useAuth } from '../useAuth';

const Admin_Notice_New = () => {
    const [title, setTitle] = useState('');
    const [post, setPost] = useState('');
    const [file, setFile] = useState(null); // 이미지 파일 상태
    const navigate = useNavigate();
    const userRole = useAuth();

  useEffect(() => {
    if (userRole !== 'ADMIN') {
      alert('관리자만 접근할 수 있는 페이지입니다.');
      navigate('/');
      return;
    }
  }, [userRole, navigate]); // 권한 확인 로직에 사용되는 변수들을 의존성 배열에 추가

    const handleFileChange = (event) => {
        setFile(event.target.files[0]);
    };

    const handleSubmit = async (event) => {
        event.preventDefault();

        const formData = new FormData();
        formData.append('file', file);

        try {
            // 이미지 업로드
            const uploadRes = await axios.post('http://localhost:8081/api/upload', formData, {
                headers: {
                    'Content-Type': 'multipart/form-data',
                },
            });

            // 공지사항 생성
            const { imgurl } = uploadRes.data;
            await axios.post('http://localhost:8081/api/notice', {
                title,
                post,
                imgurl,
            });

            alert('공지사항이 성공적으로 작성되었습니다.');
            navigate('/admin/notice');
        } catch (error) {
            console.error('공지사항 작성 실패', error);
            alert('공지사항 작성에 실패했습니다.');
        }
    };

    return (
        <form onSubmit={handleSubmit}>
            <label htmlFor="title">제목</label>
            <input id="title" value={title} onChange={(e) => setTitle(e.target.value)} />

            <label htmlFor="post">내용</label>
            <textarea id="post" value={post} onChange={(e) => setPost(e.target.value)} />

            <label htmlFor="file">이미지 첨부</label>
            <input
                type="file"
                accept="image/*"
                onChange={handleFileChange}
            />

            <button type="submit">작성하기</button>
        </form>
    );
}

export default Admin_Notice_New;
