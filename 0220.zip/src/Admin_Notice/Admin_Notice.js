import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import axios from 'axios';
import { useAuth } from '../useAuth';
import './Admin_Notice.css';

const Admin_Notice = () => {
  const [notices, setNotices] = useState([]);
  const navigate = useNavigate();
  const userRole = useAuth();

  useEffect(() => {
    console.log(userRole);
    if (userRole !== 'ROLE_ADMIN') {
      console.log(userRole);
      alert('관리자만 접근할 수 있는 페이지입니다.');
      navigate('/');
      return;
    }
  }, [userRole, navigate]); // 권한 확인 로직에 사용되는 변수들을 의존성 배열에 추가

  useEffect(() => {
    const fetchNotices = async () => {
      try {
        const response = await axios.get('http://localhost:8081/api/notice');
        setNotices(response.data);
      } catch (error) {
        console.error('공지사항 데이터를 불러오는 데 실패했습니다.', error);
      }
    };

    fetchNotices();
  }, []); //맨 마지막 괄호[] : 의존성 배열 //빈 배열이 들어가는 이유 : 컴포넌트가 마운트될 때 한번만 실행되어야 함. 비어있지 않으면 값이 변할 때마다 호출해서 계속 실행됨

  const write = () => {
    navigate('/admin/notice/new');
  };
  return (
    <div className="notice-container">
      <div className="notice-header">
        <h1>공지사항</h1>
      </div>
      <div className="notice-list">
        <table className="notice-table">
          <thead>
            <tr>
              <th>번호</th>
              <th>제목</th>
              <th>작성일</th>
            </tr>
          </thead>
          <tbody>
            {notices.map((notice) => (
              <tr key={notice.num}>
                <td>{notice.num}</td>
                <td>
                  <Link to={`/admin/notice/${notice.num}`}>{notice.title}</Link>
                </td>
                <td>{new Date(notice.createDate).toLocaleDateString()}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <div className="notice-pagination">
        <button onClick={write}>글 쓰기</button>
        <button>&lt;</button>
        <button className="active">1</button>
        <button>&gt;</button>
      </div>
    </div>
  );
}

export default Admin_Notice;
